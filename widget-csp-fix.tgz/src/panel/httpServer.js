const path = require("path");
const express = require("express");
const cookieParser = require("cookie-parser");
const { env } = require("../config/env");
const { logger } = require("../utils/logger");
const { createPanelRouter } = require("./routes");
const { createUserRouter } = require("./userRoutes");

const AUTH_WINDOW_MS = 60 * 1000;
const AUTH_MAX_HITS = 10;
const authHits = new Map();

function clientIp(req) {
  const xf = String(req.headers["x-forwarded-for"] || "")
    .split(",")[0]
    .trim();
  return xf || req.ip || req.socket?.remoteAddress || "unknown";
}

function rateLimitAuth(req, res, next) {
  const key = `${clientIp(req)}:${req.path}`;
  const now = Date.now();
  let bucket = authHits.get(key);
  if (!bucket || now - bucket.start > AUTH_WINDOW_MS) {
    bucket = { start: now, count: 0 };
    authHits.set(key, bucket);
  }
  bucket.count += 1;
  if (bucket.count > AUTH_MAX_HITS) {
    res.setHeader("Retry-After", "60");
    return res.status(429).json({ error: "too_many_requests" });
  }
  return next();
}

function originFromConfiguredUrl(value) {
  try {
    return new URL(String(value || "").trim()).origin;
  } catch (_) {
    return "";
  }
}

function hostnameFromUrl(value, fallback = "") {
  try {
    return new URL(String(value || "").trim()).hostname.toLowerCase();
  } catch (_) {
    return fallback;
  }
}

function workerMirrorOrigins() {
  return ["https://garbona.cc", "https://www.garbona.cc", "https://panel.garbona.cc"];
}

function isAllowedOrigin(origin) {
  if (!origin) return false;
  const allowed = new Set(
    [env.panelPublicUrl, env.adminPanelUrl, env.manualsDocsUrl, ...workerMirrorOrigins()]
      .map(originFromConfiguredUrl)
      .filter(Boolean)
  );
  if (allowed.has(origin)) return true;
  try {
    const host = new URL(origin).hostname.toLowerCase();
    if (host === "garbona.bothost.tech") return true;
    if (host === "localhost" || host === "127.0.0.1") return true;
  } catch (_) {
    return false;
  }
  return false;
}

function requestHostname(req) {
  const raw = String(req.headers["x-forwarded-host"] || req.headers.host || "")
    .split(",")[0]
    .trim()
    .toLowerCase();
  return raw.replace(/:\d+$/, "");
}

function isLoopbackHost(hostname) {
  return (
    !hostname ||
    hostname === "localhost" ||
    hostname === "127.0.0.1" ||
    hostname === "::1" ||
    hostname === "[::1]"
  );
}

function docsPublicHostname() {
  return hostnameFromUrl(
    env.manualsDocsUrl || "https://docs.garbona.cc/docs/#getting-started",
    "docs.garbona.cc"
  );
}

function adminPublicHostname() {
  return hostnameFromUrl(env.adminPanelUrl || "https://admin.garbona.cc", "admin.garbona.cc");
}

function workerPublicHostnames() {
  const main = hostnameFromUrl(env.panelPublicUrl, "garbona.cc");
  return new Set(
    [main, `www.${main}`, "garbona.cc", "www.garbona.cc", "panel.garbona.cc"].filter(Boolean)
  );
}

function hostKind(hostname) {
  if (isLoopbackHost(hostname)) return "local";
  const docsHost = docsPublicHostname();
  if (hostname === docsHost || hostname === `www.${docsHost}`) return "docs";
  if (hostname === adminPublicHostname()) return "admin";
  if (workerPublicHostnames().has(hostname)) return "worker";
  return "other";
}

function csrfGuard(req, res, next) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  if (!req.path.startsWith("/api")) return next();

  const host = requestHostname(req);
  if (isLoopbackHost(host) && !req.headers.origin && !req.headers.referer) {
    return next();
  }

  const origin = String(req.headers.origin || "").trim();
  const referer = String(req.headers.referer || "").trim();
  if (origin) {
    if (!isAllowedOrigin(origin)) {
      return res.status(403).json({ error: "forbidden_origin" });
    }
    return next();
  }
  if (referer) {
    try {
      const refOrigin = new URL(referer).origin;
      if (!isAllowedOrigin(refOrigin)) {
        return res.status(403).json({ error: "forbidden_origin" });
      }
      return next();
    } catch (_) {
      return res.status(403).json({ error: "forbidden_origin" });
    }
  }
  // Mini App auth may omit Origin on some clients.
  if (/\/api\/user\/auth\/(telegram|webapp)$/.test(req.path)) return next();
  return res.status(403).json({ error: "forbidden_origin" });
}

function securityHeaders(req, res, next) {
  const p = req.path || "";
  const isWorkerLogin = p === "/app/login.html" || p.endsWith("/app/login.html");
  const isAdminLogin = p === "/login.html";

  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  // Telegram Login opens oauth.telegram.org popup and needs opener access.
  res.setHeader(
    "Cross-Origin-Opener-Policy",
    isWorkerLogin ? "same-origin-allow-popups" : "same-origin"
  );
  res.setHeader("X-DNS-Prefetch-Control", "off");
  res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
  if (
    String(env.panelPublicUrl || "").startsWith("https") ||
    String(env.adminPanelUrl || "").startsWith("https")
  ) {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }

  if (isAdminLogin) {
    res.setHeader(
      "Content-Security-Policy",
      [
        "default-src 'self'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'none'",
        "img-src 'self' data:",
        "style-src 'self' https://fonts.googleapis.com",
        "font-src 'self' https://fonts.gstatic.com data:",
        "script-src 'self' 'unsafe-inline'",
        "connect-src 'self'",
      ].join("; ")
    );
  } else if (isWorkerLogin) {
    res.setHeader(
      "Content-Security-Policy",
      [
        "default-src 'self'",
        "base-uri 'self'",
        "form-action 'self' https://oauth.telegram.org",
        "frame-ancestors 'none'",
        "frame-src https://oauth.telegram.org https://telegram.org",
        "img-src 'self' data: https://telegram.org https://*.telegram.org",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        "font-src 'self' https://fonts.gstatic.com data:",
        "script-src 'self' 'unsafe-inline' https://telegram.org",
        "connect-src 'self' https://telegram.org https://oauth.telegram.org",
      ].join("; ")
    );
  }
  next();
}

function apiHostGuard(req, res, next) {
  const kind = hostKind(requestHostname(req));
  if (kind === "local") return next();

  const p = req.path;
  if (p.startsWith("/api/user")) {
    if (kind === "docs" || kind === "other") {
      return res.status(404).json({ error: "not_found" });
    }
    return next();
  }
  if (p.startsWith("/api/")) {
    if (kind !== "admin") {
      return res.status(404).json({ error: "not_found" });
    }
  }
  return next();
}

function startPanelServer(bot) {
  const app = express();
  const panelRoot = path.resolve(__dirname, "../../panel");
  const workerRoot = path.resolve(panelRoot, "worker");
  const docsRoot = path.resolve(__dirname, "../../docs-site");

  app.disable("x-powered-by");
  app.set("trust proxy", 1);

  app.use(securityHeaders);
  app.use((req, res, next) => {
    const host = requestHostname(req);
    const kind = hostKind(host);
    if (kind === "local") return next();

    if (kind === "docs") {
      if (req.path === "/" || req.path === "") return res.redirect(308, "/docs/");
      if (req.path.startsWith("/docs") || req.path.startsWith("/api")) return next();
      return res.redirect(308, "/docs/");
    }

    if (kind === "admin") {
      if (req.path.startsWith("/app") || req.path.startsWith("/docs") || req.path.startsWith("/worker")) {
        return res.status(404).send("Not found");
      }
      return next();
    }

    if (kind === "worker") {
      if (req.path === "/" || req.path === "" || req.path === "/index.html" || req.path === "/login.html") {
        return res.redirect(308, "/app/");
      }
      if (
        req.path.startsWith("/app") ||
        req.path.startsWith("/api/user") ||
        req.path.startsWith("/worker") ||
        req.path.startsWith("/assets")
      ) {
        return next();
      }
      if (req.path.startsWith("/api")) {
        return res.status(404).json({ error: "not_found" });
      }
      return res.redirect(308, "/app/");
    }

    return res.status(404).send("Not found");
  });

  app.use(express.json({ limit: "256kb" }));
  app.use(express.urlencoded({ extended: false, limit: "256kb" }));
  app.use(cookieParser());
  app.use(csrfGuard);
  app.use(apiHostGuard);

  app.use("/api/user/auth/telegram", rateLimitAuth);
  app.use("/api/user/auth/webapp", rateLimitAuth);
  app.use("/api/auth/login", rateLimitAuth);

  app.use("/api/user", createUserRouter(bot));
  app.use("/api", createPanelRouter(bot));

  app.get(/^\/docs$/, (_req, res) => {
    res.redirect(308, "/docs/");
  });
  app.get("/docs/", (req, res, next) => {
    const kind = hostKind(requestHostname(req));
    if (kind !== "local" && kind !== "docs") return next();
    res.setHeader("Cache-Control", "no-cache");
    res.sendFile(path.join(docsRoot, "index.html"));
  });
  app.use("/docs", (req, res, next) => {
    const kind = hostKind(requestHostname(req));
    if (kind !== "local" && kind !== "docs") return next("route");
    return express.static(docsRoot, {
      index: false,
      dotfiles: "deny",
      maxAge: "1y",
      immutable: true,
    })(req, res, next);
  });

  app.use("/app", (req, res, next) => {
    const kind = hostKind(requestHostname(req));
    if (kind !== "local" && kind !== "worker") return res.status(404).send("Not found");
    return next();
  });
  app.use(
    "/app",
    express.static(workerRoot, { index: false, extensions: ["html"], dotfiles: "deny" })
  );
  app.get(["/app", "/app/"], (req, res) => {
    const kind = hostKind(requestHostname(req));
    if (kind !== "local" && kind !== "worker") return res.status(404).send("Not found");
    res.redirect("/app/index.html");
  });
  app.use("/app", (req, res, next) => {
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    res.status(404).sendFile(path.join(workerRoot, "404.html"));
  });

  app.use("/worker", (req, res) => {
    const suffix = req.url && req.url !== "/" ? req.url : "/";
    res.redirect(301, `/app${suffix}`);
  });

  app.use((req, res, next) => {
    if (/\.(?:html?|js)$/i.test(req.path) || req.path === "/" || req.path === "") {
      res.setHeader("Cache-Control", "no-store");
    }
    next();
  });

  app.use((req, res, next) => {
    const kind = hostKind(requestHostname(req));
    if (kind !== "local" && kind !== "admin") return next("route");
    return express.static(panelRoot, {
      index: false,
      extensions: ["html"],
      dotfiles: "deny",
      setHeaders(res) {
        res.setHeader("Cache-Control", "no-store");
      },
    })(req, res, next);
  });

  app.get("/", (req, res) => {
    const kind = hostKind(requestHostname(req));
    if (kind === "worker") return res.redirect(308, "/app/");
    if (kind === "docs") return res.redirect(308, "/docs/");
    res.redirect("/index.html");
  });

  app.use((req, res, next) => {
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    if (req.path.startsWith("/api")) {
      return res.status(404).json({ error: "not_found" });
    }
    res.status(404).sendFile(path.join(workerRoot, "404.html"));
  });

  const port = Number(env.panelPort) || 3000;
  const host = "0.0.0.0";
  const server = app.listen(port, host, () => {
    const publicUrl = env.panelPublicUrl || `http://127.0.0.1:${port}`;
    const adminUrl = env.adminPanelUrl || publicUrl;
    const docsUrl = env.manualsDocsUrl || `${publicUrl}/docs/`;
    logger.info(`Panel server listening on http://${host}:${port} → ${publicUrl}`);
    logger.info(`Admin panel: ${adminUrl}/`);
    logger.info(`Worker app: ${publicUrl}/app/`);
    logger.info(`Documentation: ${docsUrl}`);
    if (env.panelAuthDisabled) {
      logger.warn("PANEL_AUTH_DISABLED is ON — never use this on a public host");
    }
  });

  setInterval(() => {
    const ts = Date.now();
    for (const [key, bucket] of authHits) {
      if (ts - bucket.start > AUTH_WINDOW_MS * 2) authHits.delete(key);
    }
  }, 60_000).unref?.();

  return server;
}

module.exports = { startPanelServer };
