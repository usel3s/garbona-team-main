const PanelAdmin = require("../models/PanelAdmin");
const User = require("../models/User");
const {
  hashAppPassword,
  verifyAppPasswordSafe,
  validateUsername,
  validateLoginPassword,
  passwordVersion,
} = require("../panel/appPassword");
const { logger } = require("../utils/logger");

const SEED_ADMINS = [
  { username: "vormafile", password: "qweasdzxcqeadzc" },
  { username: "karmaceo", password: "MorfiMist2020$" },
];

function normalizeUsername(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function syntheticTelegramId(username) {
  return `padmin:${normalizeUsername(username)}`;
}

async function ensureLinkedUser(admin) {
  const telegramId = syntheticTelegramId(admin.username);
  let user = await User.findOne({ telegramId });
  if (!user) {
    user = await User.create({
      telegramId,
      username: admin.username,
      firstName: admin.displayName || admin.username,
      role: "admin",
      isTeamMember: true,
    });
  } else {
    let dirty = false;
    if (user.role !== "admin") {
      user.role = "admin";
      dirty = true;
    }
    if (!user.isTeamMember) {
      user.isTeamMember = true;
      dirty = true;
    }
    if (dirty) await user.save();
  }
  return { user, telegramId };
}

async function upsertPanelAdmin(username, password, displayName = "", { forcePassword = false } = {}) {
  const checked = validateUsername(username);
  if (!checked.ok) throw new Error(checked.error || "invalid_username");
  if (!password) throw new Error("invalid_password");

  const login = checked.username;
  const existing = await PanelAdmin.findOne({ username: login });
  if (existing && !forcePassword) {
    await ensureLinkedUser(existing);
    return existing;
  }

  const passwordHash = hashAppPassword(password);
  const admin = await PanelAdmin.findOneAndUpdate(
    { username: login },
    {
      $set: {
        passwordHash,
        displayName: String(displayName || username).trim() || login,
        active: true,
        sessionVersion: existing ? Number(existing.sessionVersion || 1) + 1 : 1,
      },
      $setOnInsert: { username: login },
    },
    { upsert: true, new: true }
  );

  await ensureLinkedUser(admin);
  return admin;
}

async function ensureSeedPanelAdmins() {
  let created = 0;
  let existingCount = 0;
  for (const row of SEED_ADMINS) {
    const login = normalizeUsername(row.username);
    const before = await PanelAdmin.findOne({ username: login });
    await upsertPanelAdmin(row.username, row.password, row.username, {
      forcePassword: false,
    });
    if (before) existingCount += 1;
    else created += 1;
  }
  return { created, existing: existingCount, total: SEED_ADMINS.length };
}

async function authenticatePanelAdmin(username, password) {
  const userCheck = validateUsername(username);
  const passCheck = validateLoginPassword(password);
  if (!userCheck.ok || !passCheck.ok) {
    verifyAppPasswordSafe(password || "x", null);
    return { ok: false, error: "invalid_credentials" };
  }

  const admin = await PanelAdmin.findOne({ username: userCheck.username, active: true });
  const ok = verifyAppPasswordSafe(password, admin?.passwordHash);
  if (!admin || !ok) {
    return { ok: false, error: "invalid_credentials" };
  }

  const { user, telegramId } = await ensureLinkedUser(admin);
  return {
    ok: true,
    admin,
    user,
    telegramId,
    sessionVersion: Number(admin.sessionVersion || 1),
    passwordVersion: passwordVersion(admin.passwordHash),
  };
}

async function getPanelAdminUserById(adminId, expected = {}) {
  if (!adminId || !/^[a-f0-9]{24}$/i.test(String(adminId))) return null;
  const admin = await PanelAdmin.findById(adminId);
  if (!admin || !admin.active) return null;

  if (
    expected.sessionVersion != null &&
    Number(admin.sessionVersion || 1) !== Number(expected.sessionVersion)
  ) {
    return null;
  }
  if (
    expected.passwordVersion &&
    passwordVersion(admin.passwordHash) !== String(expected.passwordVersion)
  ) {
    return null;
  }

  const { user, telegramId } = await ensureLinkedUser(admin);
  return { admin, user, telegramId };
}

async function markPanelAdminLogin(adminId, ip) {
  await PanelAdmin.updateOne(
    { _id: adminId },
    {
      $set: {
        lastLoginAt: new Date(),
        lastLoginIp: String(ip || "").slice(0, 64),
      },
    }
  );
}

async function seedPanelAdminsOnBoot() {
  try {
    const result = await ensureSeedPanelAdmins();
    logger.info(
      `Panel admins ready: ${result.total} (new ${result.created}, existing ${result.existing})`
    );
  } catch (error) {
    logger.error("Failed to seed panel admins", error);
    throw error;
  }
}

module.exports = {
  SEED_ADMINS,
  normalizeUsername,
  syntheticTelegramId,
  upsertPanelAdmin,
  ensureSeedPanelAdmins,
  authenticatePanelAdmin,
  getPanelAdminUserById,
  markPanelAdminLogin,
  seedPanelAdminsOnBoot,
};
