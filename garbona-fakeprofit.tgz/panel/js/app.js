(async function () {
  const user = await GarbonaPanelAuth.requireAuth();
  if (!user) return;

  PanelMember.mount();

  const TITLES = {
    overview: "Обзор",
    users: "Участники",
    admins: "Администраторы",
    comms: "Коммуникация",
    stats: "Статистика",
    apps: "Заявки",
    economy: "Экономика",
    sites: "Сайты",
    templates: "Шаблоны",
    payouts: "Выплаты",
    steam: "Логи Steam",
    botlogs: "Логи бота",
  };

  const main = document.getElementById("main");
  const pageTitle = document.getElementById("pageTitle");
  const sidebar = document.getElementById("sidebar");
  const backdrop = document.getElementById("sidebarBackdrop");
  const mobileNav = document.getElementById("mobileNav");
  const mobileMore = document.getElementById("mobileMore");
  const mobileMoreSheet = document.getElementById("mobileMoreSheet");
  const mobileMoreBtn = document.getElementById("mobileMoreBtn");
  const sidebarCollapse = document.getElementById("sidebarCollapse");
  const PRIMARY_MOBILE_VIEWS = new Set(["overview", "users", "apps", "payouts"]);
  const SIDEBAR_STORAGE_KEY = "garbona-admin-sidebar-collapsed";
  let statsPeriod = "all";
  let appsKind = "pending";
  let appsPage = 0;
  let mobileMoreReturnFocus = null;

  function displayName() {
    return user.firstName || user.username || user.telegramId || "Администратор";
  }

  function avatarUrl() {
    const photo = String(user.photoUrl || "").trim();
    if (/^https?:\/\//i.test(photo)) return photo;
    const username = String(user.username || "")
      .trim()
      .replace(/^@/, "");
    if (/^[A-Za-z0-9_]{5,32}$/.test(username)) {
      return `https://t.me/i/userpic/320/${username}.jpg`;
    }
    return "assets/logo.png";
  }

  function applyUserIdentity() {
    const name = displayName();
    const role = user.roleLabel || "Администратор";
    const avatar = avatarUrl();
    ["userName", "mobileUserName"].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.textContent = name;
    });
    ["userRole", "mobileUserRole"].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.textContent = role;
    });
    ["userAvatar", "mobileUserAvatar"].forEach((id) => {
      const img = document.getElementById(id);
      if (!img) return;
      img.onerror = () => {
        img.onerror = null;
        img.src = "assets/logo.png";
      };
      img.src = avatar;
      img.alt = name;
    });
  }

  async function logout() {
    await GarbonaPanelAuth.logout();
    location.replace("login.html");
  }

  applyUserIdentity();
  document.getElementById("logoutBtn").addEventListener("click", logout);
  document.getElementById("mobileMoreLogoutBtn")?.addEventListener("click", logout);

  function setSidebarCollapsed(collapsed) {
    if (collapsed) document.documentElement.setAttribute("data-sidebar", "collapsed");
    else document.documentElement.removeAttribute("data-sidebar");
    const label = collapsed ? "Развернуть меню" : "Свернуть меню";
    sidebarCollapse?.setAttribute("aria-pressed", String(collapsed));
    sidebarCollapse?.setAttribute("aria-label", label);
    try {
      localStorage.setItem(SIDEBAR_STORAGE_KEY, collapsed ? "1" : "0");
    } catch (_) {}
  }

  let sidebarCollapsed = false;
  try {
    sidebarCollapsed = localStorage.getItem(SIDEBAR_STORAGE_KEY) === "1";
  } catch (_) {}
  setSidebarCollapsed(sidebarCollapsed);
  sidebarCollapse?.addEventListener("click", () => {
    sidebarCollapsed = !sidebarCollapsed;
    setSidebarCollapsed(sidebarCollapsed);
  });

  function setSidebarOpen(open) {
    sidebar.classList.toggle("is-open", open);
    backdrop.classList.toggle("is-visible", open);
    document.body.classList.toggle("menu-open", open);
    sidebar.setAttribute("aria-hidden", String(!open && window.matchMedia("(max-width: 900px)").matches));
  }

  function setMobileMoreOpen(open) {
    if (!mobileMore) return;
    if (open) mobileMoreReturnFocus = document.activeElement;
    mobileMore.classList.toggle("is-open", open);
    mobileMore.setAttribute("aria-hidden", String(!open));
    mobileMoreBtn?.setAttribute("aria-expanded", String(open));
    document.body.classList.toggle("mobile-more-open", open);
    if (open) {
      requestAnimationFrame(() => mobileMoreSheet?.focus());
    } else if (mobileMoreReturnFocus instanceof HTMLElement) {
      mobileMoreReturnFocus.focus({ preventScroll: true });
      mobileMoreReturnFocus = null;
    }
  }

  function syncMobileNav(viewId) {
    if (!mobileNav) return;
    const moreActive = !PRIMARY_MOBILE_VIEWS.has(viewId);
    mobileNav.querySelectorAll(".mobile-nav-item").forEach((el) => {
      if (el.dataset.menu === "more") {
        el.classList.toggle("is-active", moreActive);
      } else {
        const active = el.dataset.view === viewId;
        el.classList.toggle("is-active", active);
        if (active) el.setAttribute("aria-current", "page");
        else el.removeAttribute("aria-current");
      }
    });
    mobileMore?.querySelectorAll("[data-view]").forEach((el) => {
      const active = el.dataset.view === viewId;
      el.classList.toggle("is-active", active);
      if (active) el.setAttribute("aria-current", "page");
      else el.removeAttribute("aria-current");
    });
  }

  document.getElementById("menuToggle").addEventListener("click", () => setSidebarOpen(true));
  document.getElementById("sidebarClose").addEventListener("click", () => setSidebarOpen(false));
  backdrop.addEventListener("click", () => setSidebarOpen(false));

  mobileNav?.addEventListener("click", (e) => {
    const btn = e.target.closest(".mobile-nav-item");
    if (!btn) return;
    if (btn.dataset.menu === "more") {
      setMobileMoreOpen(true);
      return;
    }
    if (btn.dataset.view) showView(btn.dataset.view);
  });

  mobileMore?.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-view]");
    if (!btn) return;
    setMobileMoreOpen(false);
    showView(btn.dataset.view);
  });
  document.getElementById("mobileMoreBackdrop")?.addEventListener("click", () => {
    setMobileMoreOpen(false);
  });
  document.getElementById("mobileMoreClose")?.addEventListener("click", () => {
    setMobileMoreOpen(false);
  });

  function toast(msg, type) {
    PanelMember.toast(msg, type);
  }

  function debounce(fn, ms) {
    let t;
    return (...a) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...a), ms);
    };
  }

  function enhanceClickableRows(root = main) {
    root.querySelectorAll(".clickable-row").forEach((row) => {
      if (row.dataset.keyboardReady === "true") return;
      row.dataset.keyboardReady = "true";
      row.tabIndex = 0;
      row.setAttribute("role", "button");
      row.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        if (event.target.closest("button, a, input, select, textarea")) return;
        event.preventDefault();
        row.click();
      });
    });
  }

  const mainObserver = new MutationObserver(() => enhanceClickableRows());
  mainObserver.observe(main, { childList: true, subtree: true });
  main.setAttribute("aria-live", "polite");

  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (mobileMore?.classList.contains("is-open")) {
      setMobileMoreOpen(false);
      return;
    }
    if (sidebar.classList.contains("is-open")) {
      setSidebarOpen(false);
    }
  });

  mobileMoreSheet?.addEventListener("keydown", (event) => {
    if (event.key !== "Tab") return;
    const focusable = Array.from(
      mobileMoreSheet.querySelectorAll(
        'button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      )
    ).filter((el) => !el.hidden && el.getClientRects().length);
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  async function showView(id) {
    const viewId = TITLES[id] ? id : "overview";
    document.querySelectorAll(".nav-item").forEach((el) => {
      el.classList.toggle("is-active", el.dataset.view === viewId);
    });
    syncMobileNav(viewId);
    pageTitle.textContent = TITLES[viewId];
    document.title = `${TITLES[viewId]} — Garbona Admin`;
    setSidebarOpen(false);
    setMobileMoreOpen(false);
    history.replaceState(null, "", `#${viewId}`);
    main.setAttribute("aria-busy", "true");
    main.innerHTML = `
      <div class="loading-state" role="status">
        <div class="loading-state-inner">
          <span class="loading-spinner" aria-hidden="true"></span>
          <span>Загрузка раздела…</span>
        </div>
      </div>`;
    main.scrollTop = 0;
    window.scrollTo({ top: 0, behavior: "auto" });
    try {
      if (viewId === "overview") await renderOverview();
      else if (viewId === "users") await renderUsers();
      else if (viewId === "admins") await renderAdmins();
      else if (viewId === "stats") await renderStats();
      else if (viewId === "economy") await renderEconomy();
      else if (viewId === "sites") await renderSites();
      else if (viewId === "templates") await renderTemplates();
      else if (viewId === "apps") await renderApps();
      else if (viewId === "comms") await renderComms();
      else if (viewId === "payouts") await renderPayouts();
      else if (viewId === "steam") await renderSteam();
      else if (viewId === "botlogs") await renderBotLogs();
    } catch (e) {
      main.innerHTML = `
        <div class="panel-card">
          <div class="empty" role="alert">
            <div class="empty-title">Не удалось загрузить раздел</div>
            <div class="empty-sub">${escapeHtml(e.message || "Неизвестная ошибка")}</div>
          </div>
        </div>`;
    } finally {
      main.setAttribute("aria-busy", "false");
      enhanceClickableRows();
    }
  }

  document.getElementById("nav").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-view]");
    if (btn) showView(btn.dataset.view);
  });

  async function openMember(telegramId) {
    const data = await PanelAPI.get(`/admin/members/${telegramId}`);
    PanelMember.open(data.member, {
      onUpdated: () => {
        if (location.hash === "#users") renderUsers();
        if (location.hash === "#stats") renderStats();
      },
    });
  }

  async function renderOverviewLegacy() {
    const [data, mafileData] = await Promise.all([
      PanelAPI.get("/admin/overview"),
      PanelAPI.get("/admin/mafiles?limit=50"),
    ]);
    const k = data.kpi;
    const mf = data.mafiles || { statuses: {}, total: 0, inventoryDisplay: "$0.00", withdrawnDisplay: "$0.00" };
    main.innerHTML = `
      <div class="greeting">
        <div>
          <h1 class="greeting-title">Добро пожаловать, <em>${escapeHtml(
            user.firstName || user.username || "admin"
          )}</em></h1>
          <p class="greeting-sub">Сводка Garbona · глобальный % ${data.globalPercent}</p>
        </div>
        <button type="button" class="btn-primary" data-goto="users">Участники</button>
      </div>
      <div class="stats-row">
        <div class="stat-card">
          <div class="stat-label">В команде</div>
          <div class="stat-value">${k.teamCount}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Заявки в очереди</div>
          <div class="stat-value">${k.pendingApps}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Профиты сегодня</div>
          <div class="stat-value">${escapeHtml(k.todayProfitDisplay)}</div>
          <div class="stat-hint ${k.todayProfitDeltaPct > 0 ? "up" : k.todayProfitDeltaPct < 0 ? "down" : ""}">
            ${k.todayProfitDeltaPct == null ? "нет базы для сравнения" : `${k.todayProfitDeltaPct > 0 ? "+" : ""}${k.todayProfitDeltaPct}% к вчера`}
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Выводы</div>
          <div class="stat-value">${k.pendingPayouts}</div>
          <div class="stat-hint">на модерации</div>
        </div>
      </div>
      <div class="mafile-overview-grid">
        <div class="kpi-chart-card mafile-donut-card">
          <div class="kpi-chart-head">
            <div>
              <div class="kpi-chart-label">Статусы MaFile</div>
              <div class="mafile-chart-sub">Наведите на сектор для подробностей</div>
            </div>
            <div class="kpi-chart-value">${mf.total || 0}</div>
          </div>
          <div id="mafileDonut"></div>
        </div>
        <div class="mafile-summary-card">
          <div class="mafile-summary-label">Инвентарь MaFile</div>
          <div class="mafile-summary-value">${escapeHtml(mf.inventoryDisplay || "$0.00")}</div>
          <div class="mafile-summary-divider"></div>
          <div class="mafile-summary-row"><span>Успешно снято</span><strong>${escapeHtml(mf.withdrawnDisplay || "$0.00")}</strong></div>
          <div class="mafile-summary-row"><span>Продано</span><strong>${escapeHtml(mf.soldDisplay || "$0.00")}</strong></div>
          <div class="mafile-summary-row"><span>Ожидают решения</span><strong>${Number(mf.statuses?.pending || 0)}</strong></div>
        </div>
      </div>
      <div class="panel-card mafile-table-card">
        <div class="panel-card-head mafile-table-head">
          <div>
            <h2 class="panel-card-title">Логи MaFile</h2>
            <p class="mafile-chart-sub">Управление статусами и суммой снятия</p>
          </div>
          <div class="mafile-table-tools">
            <input class="search-input" id="mafileSearch" type="search" placeholder="ID, аккаунт или воркер" />
            <select class="settings-input mafile-status-filter" id="mafileStatusFilter">
              <option value="">Все статусы</option>
              <option value="pending">В ожидании</option>
              <option value="withdrawn">Снят</option>
              <option value="sold">Продан</option>
              <option value="invalid">Невалид</option>
            </select>
          </div>
        </div>
        <div class="panel-card-body mafile-table-body">
          <div class="table-wrap">
            <table class="data mafile-data-table">
              <thead><tr><th>ID</th><th>Дата</th><th>Аккаунт</th><th>Стоимость</th><th>Статус</th><th aria-label="Действия"></th></tr></thead>
              <tbody id="mafileRows"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    main.querySelector("[data-goto]")?.addEventListener("click", () => showView("users"));
    PanelCharts.renderDonutChart(document.getElementById("mafileDonut"), [
      { label: "В ожидании", value: Number(mf.statuses?.pending || 0), color: "#f2b84b", detail: `${Number(mf.statuses?.pending || 0)} ожидают снятия` },
      { label: "Успешно снят", value: Number(mf.statuses?.withdrawn || 0), color: "#48c78e", detail: `${Number(mf.statuses?.withdrawn || 0)} успешно обработано · ${mf.withdrawnDisplay || "$0.00"}` },
      { label: "Продан", value: Number(mf.statuses?.sold || 0), color: "#7aa2f7", detail: `${Number(mf.statuses?.sold || 0)} продано · ${mf.soldDisplay || "$0.00"}` },
      { label: "Невалид", value: Number(mf.statuses?.invalid || 0), color: "#ee6677", detail: `${Number(mf.statuses?.invalid || 0)} не удалось снять` },
    ], { centerLabel: "MaFile", ariaLabel: "Распределение MaFile по статусам" });

    const rowsBody = document.getElementById("mafileRows");
    let currentRows = Array.isArray(mafileData?.rows) ? mafileData.rows : [];

    function statusBadge(row) {
      const cls = row.status === "withdrawn" || row.status === "sold" ? "ok" : row.status === "invalid" ? "bad" : "wait";
      return `<span class="badge ${cls}">${escapeHtml(row.statusLabel || "В ожидании снятия")}</span>`;
    }

    function dateTime(value) {
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return "—";
      return date.toLocaleString("ru-RU", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
    }

    function renderMafileRows(rows) {
      rowsBody.innerHTML = "";
      if (!rows.length) {
        rowsBody.innerHTML = `<tr><td colspan="6" class="muted">MaFile не найдены</td></tr>`;
        return;
      }
      rows.forEach((row) => {
        const tr = document.createElement("tr");
        const ownerName = row.owner?.firstName || (row.owner?.username ? `@${row.owner.username}` : row.ownerTelegramId || "—");
        const account = row.accountUsername || row.steamId || "—";
        tr.innerHTML = `
          <td><strong>#${escapeHtml(row.sourceId)}</strong><small>${escapeHtml(row.owner?.username ? `@${row.owner.username}` : "")}</small></td>
          <td class="muted">${escapeHtml(dateTime(row.createdAt))}</td>
          <td><strong>${escapeHtml(account)}</strong><small>${escapeHtml(ownerName)} · ID ${escapeHtml(row.ownerTelegramId || "—")}</small></td>
          <td><strong>$${Number(row.totalProfit || 0).toFixed(2)}</strong><small>инв. $${Number(row.inventoryUsd || 0).toFixed(2)}</small></td>
          <td>${statusBadge(row)}</td>
          <td class="mafile-action-cell">
            <button type="button" class="mafile-menu-btn" data-menu-id="${escapeHtml(row.sourceId)}" aria-label="Управление MaFile">•••</button>
            <div class="mafile-status-menu" data-status-menu="${escapeHtml(row.sourceId)}" hidden>
              <div class="mafile-status-menu-title">Статус</div>
              <button type="button" data-set-status="pending">В ожидании снятия</button>
              <button type="button" data-set-status="withdrawn">Успешно снят</button>
              <button type="button" data-set-status="sold">Продан</button>
              <button type="button" data-set-status="invalid">Невалид</button>
            </div>
          </td>`;
        rowsBody.appendChild(tr);
      });
    }

    function askWithdrawnAmount(row) {
      return new Promise((resolve) => {
        const overlay = document.createElement("div");
        overlay.className = "mafile-dialog-backdrop";
        overlay.innerHTML = `<form class="mafile-dialog">
          <div class="mafile-dialog-kicker">MaFile #${escapeHtml(row.sourceId)}</div>
          <h3>Сумма успешного снятия</h3>
          <p>Укажите сумму, которую фактически получил воркер.</p>
          <label>Сумма, USD<input class="settings-input" name="amount" type="number" min="0" step="0.01" value="${Number(row.withdrawnAmount || 0).toFixed(2)}" required /></label>
          <div class="mafile-dialog-actions"><button type="button" class="btn-ghost" data-cancel>Отмена</button><button type="submit" class="btn-primary">Сохранить</button></div>
        </form>`;
        document.body.appendChild(overlay);
        const input = overlay.querySelector("input");
        setTimeout(() => { input.focus(); input.select(); }, 0);
        overlay.querySelector("[data-cancel]").addEventListener("click", () => { overlay.remove(); resolve(null); });
        overlay.addEventListener("click", (event) => { if (event.target === overlay) { overlay.remove(); resolve(null); } });
        overlay.querySelector("form").addEventListener("submit", (event) => {
          event.preventDefault();
          const amount = Number(input.value);
          if (!Number.isFinite(amount) || amount < 0) return;
          overlay.remove(); resolve(amount);
        });
      });
    }

    function askSoldAmount(row) {
      return new Promise((resolve) => {
        const overlay = document.createElement("div");
        overlay.className = "mafile-dialog-backdrop";
        overlay.innerHTML = `<form class="mafile-dialog">
          <div class="mafile-dialog-kicker">MaFile #${escapeHtml(row.sourceId || row.id || "")}</div>
          <h3>Сумма продажи</h3>
          <p>Воркеру начислится 80% от этой суммы (по его проценту).</p>
          <label>Продано за, USD<input class="settings-input" name="amount" type="number" min="0.01" step="0.01" value="${Number(row.withdrawnAmount || row.localMafile?.withdrawnAmount || row.totalProfit || row.totalUsd || 0).toFixed(2)}" required /></label>
          <div class="mafile-dialog-actions"><button type="button" class="btn-ghost" data-cancel>Отмена</button><button type="submit" class="btn-primary">Продать и начислить</button></div>
        </form>`;
        document.body.appendChild(overlay);
        const input = overlay.querySelector("input");
        setTimeout(() => { input.focus(); input.select(); }, 0);
        overlay.querySelector("[data-cancel]").addEventListener("click", () => { overlay.remove(); resolve(null); });
        overlay.addEventListener("click", (event) => { if (event.target === overlay) { overlay.remove(); resolve(null); } });
        overlay.querySelector("form").addEventListener("submit", (event) => {
          event.preventDefault();
          const amount = Number(input.value);
          if (!Number.isFinite(amount) || amount <= 0) return;
          overlay.remove(); resolve(amount);
        });
      });
    }

    async function setMafileStatus(row, status) {
      let amount = 0;
      if (status === "withdrawn") {
        amount = await askWithdrawnAmount(row);
        if (amount == null) return;
      }
      if (status === "sold") {
        amount = await askSoldAmount(row);
        if (amount == null) return;
      }
      try {
        const result = await PanelAPI.patch(`/admin/mafiles/${encodeURIComponent(row.sourceId)}/status`, { status, amount });
        const soldHint = status === "sold" && Number(result.workerShare || 0) > 0
          ? ` · воркеру ${Number(result.workerPercent || 80)}% $${Number(result.workerShare).toFixed(2)}`
          : "";
        toast(result.telegramUpdated ? `Статус сохранён, пост в Telegram обновлён${soldHint}` : `Статус сохранён${soldHint}`, "success");
        PanelAPI.bust("/admin/overview");
        PanelAPI.bust("/admin/mafiles");
        await renderOverview();
      } catch (error) {
        toast(error.message, "error");
      }
    }

    rowsBody.addEventListener("click", async (event) => {
      const menuBtn = event.target.closest("[data-menu-id]");
      if (menuBtn) {
        const menu = rowsBody.querySelector(`[data-status-menu="${CSS.escape(menuBtn.dataset.menuId)}"]`);
        rowsBody.querySelectorAll("[data-status-menu]").forEach((item) => { if (item !== menu) item.hidden = true; });
        menu.hidden = !menu.hidden;
        return;
      }
      const statusBtn = event.target.closest("[data-set-status]");
      if (!statusBtn) return;
      const menu = statusBtn.closest("[data-status-menu]");
      const row = currentRows.find((item) => String(item.sourceId) === String(menu.dataset.statusMenu));
      if (row) await setMafileStatus(row, statusBtn.dataset.setStatus);
    });

    async function loadMafileRows() {
      const q = document.getElementById("mafileSearch").value.trim();
      const status = document.getElementById("mafileStatusFilter").value;
      const path = `/admin/mafiles?limit=50${q ? `&q=${encodeURIComponent(q)}` : ""}${status ? `&status=${encodeURIComponent(status)}` : ""}`;
      const result = await PanelAPI.get(path, { force: true });
      currentRows = Array.isArray(result?.rows) ? result.rows : [];
      renderMafileRows(currentRows);
    }
    renderMafileRows(currentRows);
    document.getElementById("mafileSearch").addEventListener("input", () => {
      clearTimeout(renderOverview._mafileSearchTimer);
      renderOverview._mafileSearchTimer = setTimeout(loadMafileRows, 250);
    });
    document.getElementById("mafileStatusFilter").addEventListener("change", loadMafileRows);
  }

  async function renderOverview() {
    const state = {
      page: 0,
      rows: [],
      selected: new Set(),
      filters: {
        search: "", status: "", mafile: "", prime: "", unlocked: "", steamLimit: "",
        levelFrom: "", levelTo: "", balanceFrom: "", balanceTo: "", invFrom: "", invTo: "",
        eloFrom: "", eloTo: "", games: "", workers: "",
      },
      pageCount: 1,
      totalCount: 0,
      availableStatuses: [],
    };

    const STATUS_META = {
      Ok: ["Валид", "valid"], Invalid: ["Невалид", "invalid"], InvalidSession: ["Сессия невалидна", "invalid"],
      Processing: ["На снятии", "processing"], OnProcessing: ["В обработке", "processing"], Empty: ["Пустой", "muted"],
      MaFile: ["MaFile", "mafile"], Sold: ["Продан", "sold"], OnHandle: ["Обрабатывается", "processing"],
      OnSell: ["На продаже", "sell"], OnHold: ["На удержании", "wait"], Processed: ["Обработан", "valid"],
      InvalidRCode: ["Неверный RCode", "invalid"], Locked: ["Заблокирован", "invalid"], Restored: ["Восстановлен", "valid"],
      Converted: ["Конвертирован", "converted"], RedLocked: ["КТ", "locked"],
    };
    const TASK_META = {
      CheckValid: ["Проверить на валид", "Проверка на валид"],
      UnlockRed: ["Снять КТ", "Снятие КТ"],
      GetMail: ["Письмо с почты", "Получение письма"],
      SellLZT: ["Продать", "Продажа на LZT"],
      MaFileLock: ["Отправить запрос на КТ", "Запрос на КТ"],
      MaFileToLog: ["Конвертировать в лог", "MaFile в лог"],
    };

    function statusBadge(status) {
      const meta = STATUS_META[status] || [status || "—", "muted"];
      return `<span class="sc-status sc-status--${meta[1]}"><i></i>${escapeHtml(meta[0])}</span>`;
    }

    function money(value) {
      return `$${Math.max(0, Number(value) || 0).toFixed(2)}`;
    }

    function dateParts(value) {
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return ["—", ""];
      return [
        date.toLocaleDateString("ru-RU", { day: "2-digit", month: "short", year: "numeric" }).replace(" г.", ""),
        date.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      ];
    }

    function icon(name) {
      const paths = {
        logs: '<path d="M4 5h16M4 12h16M4 19h10"/>',
        search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
        filter: '<path d="M4 5h16l-6 7v6l-4 2v-8z"/>',
        refresh: '<path d="M20 6v5h-5M4 18v-5h5"/><path d="M18 9a7 7 0 0 0-12-2M6 15a7 7 0 0 0 12 2"/>',
        copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
      };
      return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.logs}</svg>`;
    }

    function queryPath() {
      const params = new URLSearchParams({ page: String(state.page), limit: "50" });
      const f = state.filters;
      if (f.search) params.set("search", f.search);
      if (f.status) params.set("statuses", f.status);
      if (f.mafile !== "") params.set("mafile_only", f.mafile);
      if (f.prime !== "") params.set("is_prime", f.prime);
      if (f.unlocked !== "") params.set("unlocked", f.unlocked);
      if (f.steamLimit !== "") params.set("steam_limit", f.steamLimit);
      if (f.levelFrom !== "") params.set("level_from", f.levelFrom);
      if (f.levelTo !== "") params.set("level_to", f.levelTo);
      if (f.balanceFrom !== "") params.set("balance_from", f.balanceFrom);
      if (f.balanceTo !== "") params.set("balance_to", f.balanceTo);
      if (f.invFrom !== "") params.set("inv_from", f.invFrom);
      if (f.invTo !== "") params.set("inv_to", f.invTo);
      if (f.eloFrom !== "") params.set("elo_from", f.eloFrom);
      if (f.eloTo !== "") params.set("elo_to", f.eloTo);
      if (f.games) params.set("games", f.games);
      if (f.workers) params.set("workers", f.workers);
      return `/admin/steam-control/accounts?${params}`;
    }

    function gamesHtml(row) {
      const games = Array.isArray(row.gamesInfo) ? row.gamesInfo.slice(0, 5) : [];
      if (!games.length) return '<span class="sc-empty">—</span>';
      return `<div class="sc-games">${games.map((game) => {
        const src = game.icon ? `https://cdn.cloudflare.steamstatic.com/steamcommunity/public/images/apps/${encodeURIComponent(game.appid)}/${encodeURIComponent(game.icon)}.jpg` : "";
        return src ? `<img src="${src}" alt="" title="${escapeHtml(game.name || "Игра")}" loading="lazy" />` : "";
      }).join("")}</div>`;
    }

    function rowMenu(row) {
      const invalid = row.status === "Invalid";
      return `<div class="sc-menu" data-sc-menu="${escapeHtml(row.id)}" hidden>
        <div class="sc-menu-title">Управление логом</div>
        <button data-task="CheckValid" ${invalid ? "disabled" : ""}>Проверить на валид</button>
        <button data-task="UnlockRed" ${row.isMaFile ? "disabled" : ""}>Снять КТ</button>
        <button data-task="GetMail" ${row.isMaFile ? "disabled" : ""}>Письмо с почты</button>
        <div class="sc-menu-sep"></div>
        <button data-task="SellLZT" ${invalid || row.isMaFile ? "disabled" : ""}>Продать</button>
        <button data-action="export">Экспорт</button>
        ${row.isMaFile ? `<div class="sc-menu-sep"></div>
          <button data-task="MaFileLock">Отправить запрос на КТ</button>
          <button data-action="download-mafile">Скачать .maFile</button>
          <button data-action="two-factor">Steam Authenticator</button>
          <button data-task="MaFileToLog">Конвертировать в лог</button>` : ""}
        <div class="sc-menu-sep"></div>
        <details class="sc-menu-status sc-menu-telegram"><summary>Telegram <span>›</span></summary><div>
          <button data-telegram-target="profit">Отправить в профит</button>
          <button data-telegram-target="worker">Отправить воркеру</button>
          <button data-telegram-target="chat">Отправить в чат</button>
        </div></details>
        ${row.localMafile ? `<div class="sc-menu-sep"></div>
        <details class="sc-menu-status" open><summary>Статус снятия Garbona <span>›</span></summary><div>
          <button data-garbona-status="pending" class="${(row.localMafile.status || "pending") === "pending" ? "is-current" : ""}">В ожидании снятия${(row.localMafile.status || "pending") === "pending" ? " · текущий" : ""}</button>
          <button data-garbona-status="withdrawn" class="${row.localMafile.status === "withdrawn" ? "is-current" : ""}">Успешно снят${row.localMafile.status === "withdrawn" ? " · текущий" : ""}</button>
          <button data-garbona-status="sold" class="${row.localMafile.status === "sold" ? "is-current" : ""}">Продан${row.localMafile.status === "sold" ? " · текущий" : ""}</button>
          <button data-garbona-status="invalid" class="${row.localMafile.status === "invalid" ? "is-current" : ""}">Невалид${row.localMafile.status === "invalid" ? " · текущий" : ""}</button>
        </div></details>` : ""}
        <div class="sc-menu-sep"></div>
        <details class="sc-menu-status"><summary>Статус UProject <span>›</span></summary><div>
          ${Object.entries(STATUS_META).map(([value, meta]) => `<button data-set-status="${value}" class="${row.status === value ? "is-current" : ""}">${escapeHtml(meta[0])}${row.status === value ? " · текущий" : ""}</button>`).join("")}
        </div></details>
        <div class="sc-menu-sep"></div>
        <button data-action="details">Полная карточка</button>
      </div>`;
    }

    function renderRows() {
      const body = document.getElementById("scRows");
      if (!body) return;
      if (!state.rows.length) {
        body.innerHTML = '<tr><td colspan="10"><div class="sc-zero">По выбранным фильтрам логов нет</div></td></tr>';
        return;
      }
      body.innerHTML = state.rows.map((row) => {
        const [day, time] = dateParts(row.createdAt);
        const steam = row.steamInfo || {};
        const worker = row.owner?.username || "—";
        const credentials = `${row.username || "—"}${row.password ? `:${row.password}` : ""}`;
        const checked = state.selected.has(String(row.id));
        const local = row.localMafile ? `<small class="sc-local-state">Garbona: ${escapeHtml(row.localMafile.status === "withdrawn" ? `снят ${money(row.localMafile.withdrawnAmount)}` : row.localMafile.status === "sold" ? `продан ${money(row.localMafile.withdrawnAmount)} · воркеру ${money(row.localMafile.workerShare || 0)}` : row.localMafile.status === "invalid" ? "невалид" : "ожидает снятия")}</small>` : "";
        return `<tr data-row-id="${escapeHtml(row.id)}">
          <td class="sc-check"><input type="checkbox" data-select-row value="${escapeHtml(row.id)}" ${checked ? "checked" : ""} aria-label="Выбрать лог ${escapeHtml(row.id)}" /></td>
          <td><button class="sc-id" data-action="details">${escapeHtml(row.id)}</button><small>${escapeHtml(worker)}</small></td>
          <td><span>${escapeHtml(day)}</span><small>${escapeHtml(time)}</small></td>
          <td><div class="sc-account">
            ${row.avatarUrl ? `<a href="${escapeHtml(row.profileUrl)}" target="_blank" rel="noreferrer"><img src="${escapeHtml(row.avatarUrl)}" alt="" /></a>` : '<span class="sc-avatar-fallback">S</span>'}
            <div><b>${escapeHtml(steam.country || "—")} · ${escapeHtml(steam.level ?? "—")} LVL</b><small>${escapeHtml(steam.nickname || row.steamId || "—")}</small>
            <button class="sc-account-tag ${row.accountTag ? "has-tag" : "is-empty"}" data-account-tag title="${row.accountTag ? "Изменить метку аккаунта" : "Добавить метку аккаунта"}">${escapeHtml(row.accountTag || "+")}</button></div>
          </div></td>
          <td>${gamesHtml(row)}</td>
          <td><b class="sc-price">${money(row.totalUsd)}</b><small>инв. ${money(row.inventoryUsd)}</small></td>
          <td>${row.CS2Info?.elo ? `<b>${Number(row.CS2Info.elo).toLocaleString("ru-RU")}</b>` : '<span class="sc-empty">—</span>'}</td>
          <td><button class="sc-credentials" data-copy="${escapeHtml(credentials)}" title="Скопировать">${escapeHtml(credentials)} ${icon("copy")}</button></td>
          <td>${statusBadge(row.status)}${local}</td>
          <td class="sc-actions"><button class="sc-more" data-toggle-menu aria-label="Управление логом">•••</button>${rowMenu(row)}</td>
        </tr>`;
      }).join("");
      syncBulkBar();
    }

    function renderPagination() {
      const box = document.getElementById("scPagination");
      if (!box) return;
      box.innerHTML = `<button data-page="${state.page - 1}" ${state.page <= 0 ? "disabled" : ""}>‹</button>
        <span>Страница <b>${state.page + 1}</b> из <b>${Math.max(1, state.pageCount)}</b></span>
        <button data-page="${state.page + 1}" ${state.page + 1 >= state.pageCount ? "disabled" : ""}>›</button>`;
    }

    function syncBulkBar() {
      const bar = document.getElementById("scBulkBar");
      const count = document.getElementById("scSelectedCount");
      if (!bar || !count) return;
      count.textContent = state.selected.size;
      bar.hidden = state.selected.size === 0;
      const all = document.getElementById("scSelectAll");
      if (all) all.checked = state.rows.length > 0 && state.rows.every((row) => state.selected.has(String(row.id)));
    }

    function closeMenus() {
      document.querySelectorAll("[data-sc-menu]").forEach((menu) => { menu.hidden = true; });
    }

    function downloadText(filename, text, type = "text/plain;charset=utf-8") {
      const url = URL.createObjectURL(new Blob([text], { type }));
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function showDialog(content, className = "") {
      const overlay = document.createElement("div");
      overlay.className = "sc-dialog-backdrop";
      overlay.innerHTML = `<section class="sc-dialog ${className}" role="dialog" aria-modal="true">${content}<button class="sc-dialog-close" data-dialog-close aria-label="Закрыть">×</button></section>`;
      document.body.appendChild(overlay);
      const close = () => overlay.remove();
      overlay.addEventListener("click", (event) => { if (event.target === overlay || event.target.closest("[data-dialog-close]")) close(); });
      return { overlay, close };
    }

    async function runTask(task, ids) {
      const meta = TASK_META[task];
      if (!meta || !ids.length) return;
      if (!(await GarbonaAdminConfirm.open(`${meta[0]} для ${ids.length} лог(ов)?`, { confirmLabel: meta[0] }))) return;
      try {
        const result = await PanelAPI.post("/admin/steam-control/tasks", { task, ids, name: meta[1] });
        toast(`Задача #${result.task?.id || "—"} создана`, "success");
        state.selected.clear();
        syncBulkBar();
        setTimeout(loadRows, 1200);
      } catch (error) { toast(error.message, "error"); }
    }

    async function exportRows(ids) {
      try {
        const data = await PanelAPI.post("/admin/steam-control/export", { ids });
        const rows = Array.isArray(data.rows) ? data.rows : [];
        const header = "ID:Login:Password:Email:EmailPass:LockCode:Limit:SteamID:LztLink:InventoryPrice";
        const lines = rows.map((row) => [
          row.id, row.username, row.password, row.steamInfo?.email, row.steamInfo?.emailPassword,
          row.steamInfo?.lockCode || row.rcode, row.steamInfo?.limited ? "Limited" : "No limit",
          row.steamInfo?.steamid, row.lztLinkId ? `https://lzt.market/${row.lztLinkId}` : "-", row.inventory?.price?.total || 0,
        ].map((value) => String(value ?? "").replaceAll("\n", " ")).join(":"));
        downloadText(`garbona-logs-${Date.now()}.txt`, [header, ...lines].join("\n"));
        toast(`Экспортировано: ${rows.length}`, "success");
      } catch (error) { toast(error.message, "error"); }
    }

    function makeMaFile(data) {
      return {
        shared_secret: data.shared_secret, serial_number: data.serial_number, revocation_code: data.revocation_code,
        uri: data.uri, server_time: data.server_time, account_name: data.account_name, token_gid: data.token_gid,
        identity_secret: data.identity_secret, secret_1: data.secret_1, status: 1,
        device_id: `android:${Math.random().toString(16).substring(2, 10)}-bbdf-c44b-07f0-91582107d977`, fully_enrolled: true,
        Session: { SessionID: "", SteamLogin: "", SteamLoginSecure: "", WebCookie: "", OAuthToken: "", SteamID: data.steamid },
      };
    }

    async function downloadMaFile(row) {
      try {
        const data = await PanelAPI.get(`/admin/steam-control/accounts/${encodeURIComponent(row.id)}/mafile`, { force: true });
        downloadText(`${row.steamId || row.id}-garbona.maFile`, JSON.stringify(makeMaFile(data), null, 2), "application/json");
      } catch (error) { toast(error.message, "error"); }
    }

    async function setLocalMafileStatus(row, status) {
      const labels = { pending: "В ожидании снятия", withdrawn: "Успешно снят", sold: "Продан", invalid: "Невалид" };
      let amount = 0;
      if (status === "withdrawn") {
        const value = window.prompt("Сумма успешного снятия, USD", String(row.localMafile?.withdrawnAmount || row.totalUsd || "0"));
        if (value == null) return;
        amount = Number(value);
        if (!Number.isFinite(amount) || amount < 0) return toast("Некорректная сумма", "error");
      }
      if (status === "sold") {
        const value = window.prompt("Сумма продажи, USD. Воркеру начислится 80%.", String(row.localMafile?.withdrawnAmount || row.totalUsd || "0"));
        if (value == null) return;
        amount = Number(value);
        if (!Number.isFinite(amount) || amount <= 0) return toast("Укажите сумму продажи больше 0", "error");
      }
      try {
        const result = await PanelAPI.patch(`/admin/mafiles/${encodeURIComponent(row.id)}/status`, { status, amount });
        PanelAPI.bust("/admin/overview");
        PanelAPI.bust("/admin/mafiles");
        const soldHint = status === "sold" && Number(result.workerShare || 0) > 0
          ? ` · воркеру ${Number(result.workerPercent || 80)}% $${Number(result.workerShare).toFixed(2)}`
          : "";
        toast(
          result?.telegramUpdated
            ? `Статус в профитах: ${labels[status] || status}${soldHint}`
            : `Статус Garbona: ${labels[status] || status}${soldHint}`,
          "success"
        );
        await loadRows();
      } catch (error) { toast(error.message, "error"); }
    }

    async function openTwoFactor(row) {
      const dialog = showDialog(`<div class="sc-dialog-kicker">Steam Guard · #${escapeHtml(row.id)}</div><h2>Steam Authenticator</h2><div class="sc-guard-code" id="scGuardCode">•••••</div><p class="sc-dialog-muted">Актуальный код и список подтверждений аккаунта.</p><div id="scConfirmations" class="sc-confirmations"><div class="sc-loading">Загрузка…</div></div>`, "sc-dialog--guard");
      async function refresh() {
        try {
          const [code, conf] = await Promise.all([
            PanelAPI.get(`/admin/steam-control/accounts/${encodeURIComponent(row.id)}/2fa/code`, { force: true }),
            PanelAPI.get(`/admin/steam-control/accounts/${encodeURIComponent(row.id)}/2fa/confirmations`, { force: true }),
          ]);
          dialog.overlay.querySelector("#scGuardCode").textContent = code?.code || "—";
          const items = Array.isArray(conf?.conf) ? conf.conf : [];
          dialog.overlay.querySelector("#scConfirmations").innerHTML = items.length ? items.map((item) => `<article class="sc-confirmation" data-conf-id="${escapeHtml(item.id)}" data-nonce="${escapeHtml(item.nonce)}"><div><b>${escapeHtml(item.headline || item.summary?.[0] || "Подтверждение")}</b><small>${escapeHtml(item.summary?.slice?.(1)?.join(" · ") || item.type_name || "Steam")}</small></div><div><button class="btn-ghost" data-conf-action="reject">Отклонить</button><button class="btn-primary" data-conf-action="accept">Подтвердить</button></div></article>`).join("") : '<div class="sc-zero">Подтверждений нет</div>';
        } catch (error) { dialog.overlay.querySelector("#scConfirmations").innerHTML = `<div class="sc-error">${escapeHtml(error.message)}</div>`; }
      }
      dialog.overlay.addEventListener("click", async (event) => {
        const btn = event.target.closest("[data-conf-action]");
        if (!btn) return;
        const item = btn.closest("[data-conf-id]");
        const accept = btn.dataset.confAction === "accept";
        if (!(await GarbonaAdminConfirm.open(accept ? "Подтвердить действие в Steam?" : "Отклонить действие в Steam?", { confirmLabel: accept ? "Подтвердить" : "Отклонить" }))) return;
        try {
          await PanelAPI.post(`/admin/steam-control/accounts/${encodeURIComponent(row.id)}/2fa/confirmations`, { confId: item.dataset.confId, nonce: item.dataset.nonce, accept });
          toast(accept ? "Подтверждено" : "Отклонено", "success");
          await refresh();
        } catch (error) { toast(error.message, "error"); }
      });
      await refresh();
    }

    async function openDetails(row) {
      const dialog = showDialog('<div class="sc-loading">Загружаю полную карточку…</div>', "sc-dialog--details");
      try {
        const data = await PanelAPI.get(`/admin/steam-control/accounts/${encodeURIComponent(row.id)}`, { force: true });
        const account = data.account || row;
        const steam = account.steamInfo || {};
        const statuses = Object.keys(STATUS_META);
        dialog.overlay.querySelector(".sc-dialog").innerHTML = `<div class="sc-dialog-kicker">Лог #${escapeHtml(account.id)}</div><h2>${escapeHtml(account.username || steam.nickname || "Steam аккаунт")}</h2>
          <button class="sc-dialog-close" data-dialog-close aria-label="Закрыть">×</button>
          <div class="sc-detail-grid">
            <section><h3>Аккаунт</h3><dl><dt>Логин</dt><dd>${escapeHtml(account.username || "—")}</dd><dt>Пароль</dt><dd>${escapeHtml(account.password || "—")}</dd><dt>Steam ID</dt><dd>${escapeHtml(steam.steamid || "—")}</dd><dt>Страна / уровень</dt><dd>${escapeHtml(steam.country || "—")} · ${escapeHtml(steam.level ?? "—")} LVL</dd><dt>Баланс</dt><dd>${money(steam.balanceUsd)}</dd><dt>Инвентарь</dt><dd>${money(account.inventoryUsd)}</dd></dl></section>
            <section><h3>Управление</h3><label>Статус аккаунта<select class="settings-input" id="scDetailStatus">${statuses.map((status) => `<option value="${status}" ${status === account.status ? "selected" : ""}>${escapeHtml(STATUS_META[status][0])}</option>`).join("")}</select></label><label>Личная метка<input class="settings-input" id="scCustomTag" value="${escapeHtml(account.customTag || "")}" maxlength="80" /></label><label>Метка команды<input class="settings-input" id="scTeamTag" value="${escapeHtml(account.customTeamTag || "")}" maxlength="80" /></label><button class="btn-primary" id="scSaveAccount">Сохранить</button></section>
          </div>
          <div class="sc-detail-actions"><button class="btn-ghost" data-detail-action="export">Экспорт</button>${account.isMaFile ? '<button class="btn-ghost" data-detail-action="mafile">Скачать .maFile</button><button class="btn-ghost" data-detail-action="guard">Steam Guard</button>' : ""}</div>
          ${account.isMaFile ? `<div class="sc-local-control"><h3>Статус снятия Garbona</h3><button data-local-status="pending">В ожидании</button><button data-local-status="withdrawn">Успешно снят</button><button data-local-status="sold">Продан</button><button data-local-status="invalid">Невалид</button></div>` : ""}`;
        dialog.overlay.querySelector("#scSaveAccount").addEventListener("click", async () => {
          try {
            const status = dialog.overlay.querySelector("#scDetailStatus").value;
            await Promise.all([
              status !== account.status ? PanelAPI.post(`/admin/steam-control/accounts/${encodeURIComponent(account.id)}/status`, { status }) : Promise.resolve(),
              PanelAPI.post(`/admin/steam-control/accounts/${encodeURIComponent(account.id)}/tags`, { customTag: dialog.overlay.querySelector("#scCustomTag").value, customTeamTag: dialog.overlay.querySelector("#scTeamTag").value }),
            ]);
            toast("Аккаунт обновлён", "success"); dialog.close(); await loadRows();
          } catch (error) { toast(error.message, "error"); }
        });
        dialog.overlay.addEventListener("click", async (event) => {
          const local = event.target.closest("[data-local-status]");
          if (local) { dialog.close(); await setLocalMafileStatus(account, local.dataset.localStatus); return; }
          const action = event.target.closest("[data-detail-action]")?.dataset.detailAction;
          if (action === "export") await exportRows([Number(account.id)]);
          if (action === "mafile") await downloadMaFile(account);
          if (action === "guard") { dialog.close(); await openTwoFactor(account); }
        });
      } catch (error) { dialog.overlay.querySelector(".sc-dialog").innerHTML = `<div class="sc-error">${escapeHtml(error.message)}</div><button class="sc-dialog-close" data-dialog-close>×</button>`; }
    }

    function openAccountTag(row) {
      const dialog = showDialog(`<div class="sc-dialog-kicker">АККАУНТ #${escapeHtml(row.id)}</div><h2>Метка для воркера</h2><p class="sc-dialog-muted">Метка появится рядом с аккаунтом в панели воркера.</p><label class="sc-tag-field">Название метки<input id="scQuickTag" type="text" maxlength="80" value="${escapeHtml(row.accountTag || "")}" placeholder="Например: высокий приоритет"></label><div class="sc-detail-actions"><button class="btn-ghost" data-tag-clear>Удалить метку</button><button class="btn-primary" data-tag-save>Сохранить</button></div>`, "sc-dialog--tag");
      const save = async (value) => {
        try {
          const saved = await PanelAPI.post(`/admin/steam-control/accounts/${encodeURIComponent(row.id)}/tags`, {
            customTag: row.customTag || "",
            customTeamTag: String(value || "").trim(),
          });
          const remoteSynced = saved?.result?.synced !== false;
          toast(remoteSynced ? (value ? "Метка сохранена" : "Метка удалена") : "Метка сохранена в Garbona", "success");
          dialog.close(); await loadRows();
        } catch (error) { toast(error.message, "error"); }
      };
      dialog.overlay.addEventListener("click", (event) => {
        if (event.target.closest("[data-tag-save]")) save(dialog.overlay.querySelector("#scQuickTag").value);
        if (event.target.closest("[data-tag-clear]")) save("");
      });
      dialog.overlay.querySelector("#scQuickTag").focus();
    }

    async function sendToTelegram(row, target) {
      const labels = { profit: "канал с профитами", worker: "личные сообщения воркера", chat: "чат команды" };
      if (!labels[target] || !(await GarbonaAdminConfirm.open(`Отправить карточку #${row.id} в ${labels[target]}?`, { confirmLabel: "Отправить" }))) return;
      try {
        await PanelAPI.post(`/admin/steam-control/accounts/${encodeURIComponent(row.id)}/telegram`, { target });
        toast(`Карточка отправлена в ${labels[target]}`, "success");
      } catch (error) { toast(error.message, "error"); }
    }

    async function openTasks() {
      const dialog = showDialog('<div class="sc-loading">Загружаю задачи…</div>', "sc-dialog--tasks");
      try {
        const data = await PanelAPI.get("/admin/steam-control/tasks?page=0&limit=30", { force: true });
        const tasks = Array.isArray(data.rows) ? data.rows : [];
        dialog.overlay.querySelector(".sc-dialog").innerHTML = `<div class="sc-dialog-kicker">ЗАДАЧИ КОМАНДЫ</div><h2>Задачи обработки</h2><button class="sc-dialog-close" data-dialog-close aria-label="Закрыть">×</button><div class="sc-task-list">${tasks.length ? tasks.map((task) => {
          const operations = Array.isArray(task.steam?.tasks) ? task.steam.tasks : [];
          const done = operations.filter((item) => item.state === "Done").length;
          const failed = operations.filter((item) => item.state === "Error").length;
          return `<article class="sc-task"><div><b>#${escapeHtml(task.id)} · ${escapeHtml(task.name || "Без названия")}</b><small>${escapeHtml(dateParts(task.createdAt).join(" · "))}</small></div><div><span class="sc-task-state sc-task-state--${String(task.state || "").toLowerCase()}">${escapeHtml(task.state || "—")}</span><small>${done} выполнено · ${failed} ошибок · ${operations.length} всего</small></div>${task.state === "InProcess" ? `<button class="btn-ghost" data-cancel-task="${escapeHtml(task.id)}">Отменить</button>` : ""}</article>`;
        }).join("") : '<div class="sc-zero">Задач пока нет</div>'}</div>`;
        dialog.overlay.addEventListener("click", async (event) => {
          const button = event.target.closest("[data-cancel-task]");
          if (!button || !(await GarbonaAdminConfirm.open(`Отменить задачу #${button.dataset.cancelTask}?`, { confirmLabel: "Отменить задачу" }))) return;
          try {
            await PanelAPI.post(`/admin/steam-control/tasks/${encodeURIComponent(button.dataset.cancelTask)}/cancel`, {});
            toast("Задача отменена", "success"); dialog.close(); await openTasks();
          } catch (error) { toast(error.message, "error"); }
        });
      } catch (error) {
        dialog.overlay.querySelector(".sc-dialog").innerHTML = `<div class="sc-error">${escapeHtml(error.message)}</div><button class="sc-dialog-close" data-dialog-close>×</button>`;
      }
    }

    async function handleRowAction(row, action, task, nextStatus, telegramTarget) {
      if (task) return runTask(task, [Number(row.id)]);
      if (telegramTarget) return sendToTelegram(row, telegramTarget);
      if (nextStatus) {
        const label = STATUS_META[nextStatus]?.[0] || nextStatus;
        if (!(await GarbonaAdminConfirm.open(`Сменить статус UProject на «${label}»?\nЭто не меняет подпись в канале профитов.`, { confirmLabel: "Сменить UProject" }))) return;
        try {
          await PanelAPI.post(`/admin/steam-control/accounts/${encodeURIComponent(row.id)}/status`, { status: nextStatus });
          toast(`UProject: ${label}`, "success");
          await loadRows();
        } catch (error) {
          const msg = String(error.message || "");
          toast(/bad request/i.test(msg) ? "UProject отклонил смену статуса для этого аккаунта" : msg, "error");
        }
        return;
      }
      if (action === "export") return exportRows([Number(row.id)]);
      if (action === "download-mafile") return downloadMaFile(row);
      if (action === "two-factor") return openTwoFactor(row);
      if (action === "details") return openDetails(row);
    }

    async function loadRows(prefetched = null) {
      const body = document.getElementById("scRows");
      if (body) body.innerHTML = '<tr><td colspan="10"><div class="sc-loading">Обновляю список логов…</div></td></tr>';
      try {
        const data = prefetched ? await prefetched : await PanelAPI.get(queryPath(), { force: true });
        if (data?.__error) throw data.__error;
        state.rows = Array.isArray(data.rows) ? data.rows : [];
        state.totalCount = Number(data.totalCount || 0);
        state.pageCount = Number(data.pageCount || 1);
        state.availableStatuses = Array.isArray(data.statuses) ? data.statuses : [];
        document.getElementById("scTableCount").textContent = state.totalCount;
        const isUnfiltered = Object.values(state.filters).every((value) => value === "");
        if (isUnfiltered) {
          document.getElementById("scLogCount").textContent = state.totalCount;
        }
        if (state.pageCount === 1 && isUnfiltered) {
          const visibleCounts = state.rows.reduce((acc, row) => { acc[row.status] = (acc[row.status] || 0) + 1; return acc; }, {});
          document.getElementById("scValidCount").textContent = visibleCounts.Ok || 0;
          document.getElementById("scMafileCount").textContent = visibleCounts.MaFile || 0;
          document.getElementById("scInvalidCount").textContent = visibleCounts.Invalid || 0;
        }
        renderRows(); renderPagination();
      } catch (error) {
        if (body) body.innerHTML = `<tr><td colspan="10"><div class="sc-error">${escapeHtml(error.message)}</div></td></tr>`;
      }
    }

    const initialRowsPromise = PanelAPI.get(queryPath(), { force: true }).catch((error) => ({ __error: error }));
    const remoteStatsPromise = PanelAPI.get("/admin/steam-control/stats", { force: true }).catch(() => ({ statuses: [] }));
    const overview = await PanelAPI.get("/admin/overview");
    const remoteStatuses = {};
    const remoteTotal = Object.values(remoteStatuses).reduce((sum, value) => sum + value, 0);
    const teamKpi = overview.kpi || {};
    const FILTER_DEFS = {
      level: { label: "Уровень Steam", kind: "range", from: "levelFrom", to: "levelTo", suffix: " LVL" },
      balance: { label: "Баланс Steam", kind: "range", from: "balanceFrom", to: "balanceTo", suffix: " $" },
      inventory: { label: "Инвентарь", kind: "range", from: "invFrom", to: "invTo", suffix: " $" },
      mafile: { label: "MaFile", kind: "choice", field: "mafile", options: [["true", "Только MaFile"], ["false", "Без MaFile"]] },
      prime: { label: "Prime", kind: "choice", field: "prime", options: [["true", "С праймом"], ["false", "Без прайма"]] },
      elo: { label: "Рейтинг CS2", kind: "range", from: "eloFrom", to: "eloTo", suffix: " ELO" },
      limit: { label: "Лимит", kind: "choice", field: "steamLimit", options: [["true", "Есть лимит"], ["false", "Без лимита"]] },
      unlocked: { label: "КТ", kind: "choice", field: "unlocked", options: [["true", "КТ снято"], ["false", "КТ не снято"]] },
      games: { label: "Игры", kind: "text", field: "games", placeholder: "App ID через запятую" },
      status: { label: "Статус", kind: "choice", field: "status", options: Object.entries(STATUS_META).map(([value, meta]) => [value, meta[0]]) },
      workers: { label: "Участник команды", kind: "text", field: "workers", placeholder: "ID участника" },
    };
    main.innerHTML = `<div class="sc-dashboard">
      <header class="sc-page-head"><div><span class="sc-eyebrow">GARБONA TEAM</span><h1>Статистика команды</h1><p>Главные показатели, динамика и управление логами в одном месте.</p></div><button class="sc-refresh" id="scRefresh" aria-label="Обновить данные">${icon("refresh")}<span>Обновить</span></button></header>
      <section class="sc-team-section"><div class="sc-section-head"><div><h2>Обзор команды</h2><p>Текущие показатели всей команды</p></div></div>
      <div class="sc-kpis">
        <article class="sc-kpi-accent"><span>Профит сегодня</span><b>${escapeHtml(teamKpi.todayProfitDisplay || "$0.00")}</b><small>${teamKpi.todayProfitDeltaPct == null ? "без сравнения" : `${teamKpi.todayProfitDeltaPct >= 0 ? "+" : ""}${teamKpi.todayProfitDeltaPct}% ко вчера`}</small></article>
        <article><span>Участники команды</span><b>${Number(teamKpi.teamCount || 0)}</b><small>${Number(teamKpi.pendingApps || 0)} заявок ожидают</small></article>
        <article><span>Все логи</span><b id="scLogCount">${remoteTotal}</b><small><i class="sc-mini-dot is-valid"></i><span id="scValidCount">${remoteStatuses.Ok || 0}</span> валидных</small></article>
        <article><span>MaFile</span><b id="scMafileCount">${remoteStatuses.MaFile || 0}</b><small>${overview.mafiles?.statuses?.pending || 0} ожидают снятия</small></article>
        <article><span>Ожидают выплаты</span><b>${Number(teamKpi.pendingPayouts || 0)}</b><small><span id="scInvalidCount">${remoteStatuses.Invalid || 0}</span> невалидных аккаунтов</small></article>
      </div>
      </section>
      <section class="sc-chart-card"><div class="sc-section-head"><div><h2>Динамика команды</h2><p>Профит и количество операций за последние 7 дней</p></div><div class="sc-chart-legend"><span><i class="is-amount"></i>Профит</span><span><i class="is-count"></i>Операции</span></div></div><div id="scTeamChart"></div></section>
      <section class="sc-workspace">
        <div class="sc-workspace-head"><div><div class="sc-title-row">${icon("logs")}<h2>Список логов</h2><span id="scTableCount">live</span></div><p>Аккаунты команды, их состояние и быстрые действия</p></div></div>
        <div class="sc-toolbar">
          <label class="sc-search">${icon("search")}<input id="scSearch" type="search" placeholder="ID, SteamID, логин, пароль или ссылка" /></label>
          <div class="sc-filter-host"><button class="sc-filter-toggle" id="scFilterToggle">${icon("filter")} Добавить фильтр <span id="scFilterCount">0</span></button><div class="sc-filter-popover" id="scFilterPopover" hidden><div id="scFilterPicker" class="sc-filter-picker">${Object.entries(FILTER_DEFS).map(([key, def]) => `<button data-filter-open="${key}"><span>${escapeHtml(def.label)}</span><b>›</b></button>`).join("")}</div><div id="scFilterEditor" class="sc-filter-editor" hidden></div></div></div>
          <button class="btn-ghost" id="scTasksButton">Задачи</button><button class="btn-ghost" id="scExportVisible">Экспорт страницы</button>
        </div>
        <div class="sc-active-filters" id="scActiveFilters" hidden></div>
        <div class="sc-bulk" id="scBulkBar" hidden><b>Выбрано: <span id="scSelectedCount">0</span></b><button data-bulk-task="CheckValid">Проверить</button><button data-bulk-task="UnlockRed">Снять КТ</button><button data-bulk-task="MaFileToLog">В лог</button><button data-bulk-task="SellLZT">Продать</button><button data-bulk-export>Экспорт</button><button data-bulk-clear>Отменить</button></div>
        <div class="sc-table-wrap"><table class="sc-table"><thead><tr><th><input id="scSelectAll" type="checkbox" aria-label="Выбрать страницу" /></th><th>ID</th><th>Дата</th><th>Аккаунт</th><th>Игры</th><th>Цена</th><th>CS2</th><th>Данные</th><th>Статус</th><th></th></tr></thead><tbody id="scRows"></tbody></table></div>
        <footer class="sc-pagination" id="scPagination"></footer>
      </section>
    </div>`;

    function filterIsActive(def) {
      if (def.kind === "range") return state.filters[def.from] !== "" || state.filters[def.to] !== "";
      return state.filters[def.field] !== "";
    }

    function filterSummary(def) {
      if (def.kind === "range") {
        const from = state.filters[def.from]; const to = state.filters[def.to];
        if (from !== "" && to !== "") return `${from}–${to}${def.suffix || ""}`;
        if (from !== "") return `от ${from}${def.suffix || ""}`;
        return `до ${to}${def.suffix || ""}`;
      }
      if (def.kind === "choice") return def.options.find(([value]) => value === state.filters[def.field])?.[1] || state.filters[def.field];
      return state.filters[def.field];
    }

    function renderActiveFilters() {
      const host = document.getElementById("scActiveFilters");
      const active = Object.entries(FILTER_DEFS).filter(([, def]) => filterIsActive(def));
      document.getElementById("scFilterCount").textContent = active.length;
      host.hidden = active.length === 0;
      host.innerHTML = active.map(([key, def]) => `<button data-remove-filter="${key}"><span>${escapeHtml(def.label)}:</span> ${escapeHtml(filterSummary(def))}<b>×</b></button>`).join("") + (active.length ? '<button class="sc-clear-filters" data-clear-filters>Сбросить всё</button>' : "");
    }

    function applyFilters() {
      renderActiveFilters();
      state.page = 0; state.selected.clear(); loadRows();
    }

    function clearFilter(key) {
      const def = FILTER_DEFS[key]; if (!def) return;
      if (def.kind === "range") { state.filters[def.from] = ""; state.filters[def.to] = ""; }
      else state.filters[def.field] = "";
    }

    function openFilterEditor(key) {
      const def = FILTER_DEFS[key]; if (!def) return;
      const editor = document.getElementById("scFilterEditor");
      document.getElementById("scFilterPicker").hidden = true; editor.hidden = false;
      let body = "";
      if (def.kind === "choice") body = `<div class="sc-filter-options">${def.options.map(([value, label]) => `<button data-filter-choice="${escapeHtml(value)}" class="${state.filters[def.field] === value ? "is-selected" : ""}">${escapeHtml(label)}<i></i></button>`).join("")}</div>`;
      if (def.kind === "range") body = `<div class="sc-filter-range"><label>От<input id="scFilterFrom" type="number" min="0" value="${escapeHtml(state.filters[def.from])}" placeholder="0"></label><label>До<input id="scFilterTo" type="number" min="0" value="${escapeHtml(state.filters[def.to])}" placeholder="∞"></label><button data-filter-apply>Применить</button></div>`;
      if (def.kind === "text") body = `<div class="sc-filter-range"><label>${escapeHtml(def.label)}<input id="scFilterText" type="text" value="${escapeHtml(state.filters[def.field])}" placeholder="${escapeHtml(def.placeholder || "Введите значение")}"></label><button data-filter-apply>Применить</button></div>`;
      editor.dataset.filterKey = key;
      editor.innerHTML = `<button class="sc-filter-back" data-filter-back>‹ Все фильтры</button><h3>${escapeHtml(def.label)}</h3>${body}`;
    }

    const searchFilters = debounce(() => { state.filters.search = document.getElementById("scSearch").value.trim(); state.page = 0; loadRows(); }, 350);
    document.getElementById("scSearch").addEventListener("input", searchFilters);
    document.getElementById("scFilterToggle").addEventListener("click", (event) => {
      event.stopPropagation();
      const popover = document.getElementById("scFilterPopover"); popover.hidden = !popover.hidden;
      document.getElementById("scFilterPicker").hidden = false; document.getElementById("scFilterEditor").hidden = true;
    });
    document.getElementById("scFilterPopover").addEventListener("click", (event) => {
      event.stopPropagation();
      const open = event.target.closest("[data-filter-open]"); if (open) return openFilterEditor(open.dataset.filterOpen);
      if (event.target.closest("[data-filter-back]")) { document.getElementById("scFilterPicker").hidden = false; document.getElementById("scFilterEditor").hidden = true; return; }
      const editor = document.getElementById("scFilterEditor"); const def = FILTER_DEFS[editor.dataset.filterKey]; if (!def) return;
      const choice = event.target.closest("[data-filter-choice]");
      if (choice) { state.filters[def.field] = choice.dataset.filterChoice; document.getElementById("scFilterPopover").hidden = true; applyFilters(); return; }
      if (event.target.closest("[data-filter-apply]")) {
        if (def.kind === "range") { state.filters[def.from] = editor.querySelector("#scFilterFrom").value; state.filters[def.to] = editor.querySelector("#scFilterTo").value; }
        else state.filters[def.field] = editor.querySelector("#scFilterText").value.trim();
        document.getElementById("scFilterPopover").hidden = true; applyFilters();
      }
    });
    document.getElementById("scActiveFilters").addEventListener("click", (event) => {
      const remove = event.target.closest("[data-remove-filter]");
      if (remove) { clearFilter(remove.dataset.removeFilter); applyFilters(); return; }
      if (event.target.closest("[data-clear-filters]")) { Object.keys(FILTER_DEFS).forEach(clearFilter); applyFilters(); }
    });
    main.addEventListener("click", (event) => { if (!event.target.closest(".sc-filter-host")) document.getElementById("scFilterPopover").hidden = true; });
    document.getElementById("scRefresh").addEventListener("click", loadRows);
    document.getElementById("scTasksButton").addEventListener("click", openTasks);
    document.getElementById("scExportVisible").addEventListener("click", () => exportRows(state.rows.map((row) => Number(row.id))));
    document.getElementById("scPagination").addEventListener("click", (event) => { const btn = event.target.closest("[data-page]"); if (!btn || btn.disabled) return; state.page = Number(btn.dataset.page); loadRows(); });
    document.getElementById("scSelectAll").addEventListener("change", (event) => { state.rows.forEach((row) => event.target.checked ? state.selected.add(String(row.id)) : state.selected.delete(String(row.id))); renderRows(); });
    document.getElementById("scBulkBar").addEventListener("click", (event) => {
      const ids = [...state.selected].map(Number);
      const task = event.target.closest("[data-bulk-task]")?.dataset.bulkTask;
      if (task) runTask(task, ids);
      if (event.target.closest("[data-bulk-export]")) exportRows(ids);
      if (event.target.closest("[data-bulk-clear]")) { state.selected.clear(); renderRows(); }
    });
    document.getElementById("scRows").addEventListener("change", (event) => {
      if (!event.target.matches("[data-select-row]")) return;
      event.target.checked ? state.selected.add(event.target.value) : state.selected.delete(event.target.value); syncBulkBar();
    });
    document.getElementById("scRows").addEventListener("click", async (event) => {
      const tr = event.target.closest("[data-row-id]"); if (!tr) return;
      const row = state.rows.find((item) => String(item.id) === tr.dataset.rowId); if (!row) return;
      const copy = event.target.closest("[data-copy]");
      if (copy) { try { await navigator.clipboard.writeText(copy.dataset.copy); toast("Данные скопированы", "success"); } catch { toast("Не удалось скопировать", "error"); } return; }
      if (event.target.closest("[data-account-tag]")) { openAccountTag(row); return; }
      const toggle = event.target.closest("[data-toggle-menu]");
      if (toggle) { const menu = tr.querySelector("[data-sc-menu]"); const open = menu.hidden; closeMenus(); menu.hidden = !open; return; }
      const garbonaStatusBtn = event.target.closest("[data-garbona-status]");
      if (garbonaStatusBtn) {
        closeMenus();
        await setLocalMafileStatus(row, garbonaStatusBtn.dataset.garbonaStatus);
        return;
      }
      const actionEl = event.target.closest("[data-action], [data-task], [data-set-status], [data-telegram-target]");
      if (actionEl) { closeMenus(); await handleRowAction(row, actionEl.dataset.action, actionEl.dataset.task, actionEl.dataset.setStatus, actionEl.dataset.telegramTarget); }
    });
    main.addEventListener("click", (event) => { if (!event.target.closest(".sc-actions")) closeMenus(); });
    renderActiveFilters();
    PanelCharts.renderSmoothLineChart(document.getElementById("scTeamChart"), (overview.series || []).map((row) => ({
      date: row.date, label: row.label, amount: row.totalUsd, amountDisplay: row.totalDisplay, count: row.count,
    })), { ariaLabel: "Динамика показателей команды", empty: "За этот период пока нет данных" });
    await loadRows(initialRowsPromise);
    remoteStatsPromise.then((remoteStats) => {
      const counts = Object.fromEntries((remoteStats.statuses || []).map((item) => [item.status, Number(item.count || 0)]));
      if (document.getElementById("scValidCount")) document.getElementById("scValidCount").textContent = counts.Ok || 0;
      if (document.getElementById("scMafileCount")) document.getElementById("scMafileCount").textContent = counts.MaFile || 0;
      if (document.getElementById("scInvalidCount")) document.getElementById("scInvalidCount").textContent = counts.Invalid || 0;
    });
  }

  async function renderAdmins() {
    const data = await PanelAPI.get("/admin/admins");
    const rows = data.admins || [];
    const activeCount = rows.filter((admin) => admin.active).length;
    const fmtDate = (value) => {
      if (!value) return "—";
      const date = new Date(value);
      return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString("ru-RU");
    };
    const initials = (admin) => String(admin.displayName || admin.username || "A")
      .split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
    const cards = rows.map((admin) => {
      const current = String(admin.username || "").toLowerCase() === String(user.username || "").toLowerCase();
      return `
        <article class="admin-person ${current ? "is-current" : ""}">
          <div class="admin-person-avatar" aria-hidden="true">${escapeHtml(initials(admin))}</div>
          <div class="admin-person-main">
            <div class="admin-person-title">
              <strong>${escapeHtml(admin.displayName || admin.username)}</strong>
              ${current ? '<span class="admin-you-badge">Вы</span>' : ""}
            </div>
            <code>@${escapeHtml(admin.username)}</code>
          </div>
          <div class="admin-person-meta">
            <span class="admin-meta-label">Последний вход</span>
            <span>${escapeHtml(fmtDate(admin.lastLoginAt))}</span>
          </div>
          <div class="admin-person-meta admin-created-by">
            <span class="admin-meta-label">Добавил</span>
            <span>${escapeHtml(admin.createdByUsername ? `@${admin.createdByUsername}` : "Первичный доступ")}</span>
          </div>
          <span class="admin-status ${admin.active ? "is-active" : "is-disabled"}"><i></i>${admin.active ? "Активен" : "Отключён"}</span>
        </article>`;
    }).join("");
    main.innerHTML = `
      <section class="admin-access-hero">
        <div class="admin-access-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 3.5 19 7.3v5.4c0 4.3-3 6.8-7 7.8-4-1-7-3.5-7-7.8V7.3L12 3.5Z" stroke="currentColor" stroke-width="1.5"/><path d="m9.2 12.1 1.8 1.9 3.9-4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </div>
        <div class="admin-access-copy"><span class="admin-access-kicker">Контроль доступа</span><h1>Администраторы</h1><p>Управляйте людьми, у которых есть полный доступ к Garbona.</p></div>
        <div class="admin-access-stats"><div><strong>${rows.length}</strong><span>всего</span></div><div><strong>${activeCount}</strong><span>активны</span></div></div>
      </section>
      <div class="admin-access-layout">
        <section class="admin-create-card">
          <div class="admin-card-heading"><span class="admin-card-number">01</span><div><h2>Новый администратор</h2><p>Создайте отдельный доступ для участника команды.</p></div></div>
          <form id="createAdminForm" class="admin-create-form" autocomplete="off">
            <label><span>Логин</span><small>Латиница, цифры, точка и дефис</small><div class="admin-input-wrap"><span class="admin-input-prefix">@</span><input name="username" required minlength="3" maxlength="32" pattern="[a-zA-Z0-9._-]+" placeholder="username" spellcheck="false" /></div></label>
            <label><span>Отображаемое имя</span><small>Так имя будет выглядеть в панели</small><div class="admin-input-wrap"><input name="displayName" maxlength="64" placeholder="Имя администратора" /></div></label>
            <label><span>Пароль</span><small id="adminPasswordHint">Минимум 8 символов</small><div class="admin-input-wrap"><input id="adminPassword" type="password" name="password" required minlength="8" maxlength="128" autocomplete="new-password" placeholder="Надёжный пароль" /><button class="admin-password-toggle" type="button" id="adminPasswordToggle" aria-label="Показать пароль"><span>Показать</span></button></div><div class="admin-password-meter"><i></i><i></i><i></i><i></i></div></label>
            <div class="admin-security-note"><svg viewBox="0 0 24 24" fill="none"><path d="M12 3.5 19 7.3v5.4c0 4.3-3 6.8-7 7.8-4-1-7-3.5-7-7.8V7.3L12 3.5Z" stroke="currentColor" stroke-width="1.5"/><path d="M9.5 12h5M12 9.5v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg><span>Пароль показывается только здесь. Передайте его по защищённому каналу.</span></div>
            <button class="admin-create-submit" type="submit"><span>Создать администратора</span><svg viewBox="0 0 24 24" fill="none"><path d="M5 12h14m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
          </form>
          <p class="admin-create-status" id="createAdminStatus" role="status"></p>
        </section>
        <section class="admin-list-card">
          <div class="admin-list-head"><div><h2>Команда доступа</h2><p>${activeCount} ${activeCount === 1 ? "активный администратор" : "активных администратора"}</p></div><span class="admin-list-lock"><i></i>Полный доступ</span></div>
          <div class="admin-people">${cards || '<div class="admin-list-empty">Администраторы ещё не добавлены</div>'}</div>
        </section>
      </div>`;
    const form = document.getElementById("createAdminForm");
    const status = document.getElementById("createAdminStatus");
    const password = document.getElementById("adminPassword");
    const passwordToggle = document.getElementById("adminPasswordToggle");
    const passwordHint = document.getElementById("adminPasswordHint");
    passwordToggle?.addEventListener("click", () => {
      const visible = password.type === "text";
      password.type = visible ? "password" : "text";
      passwordToggle.querySelector("span").textContent = visible ? "Показать" : "Скрыть";
      passwordToggle.setAttribute("aria-label", visible ? "Показать пароль" : "Скрыть пароль");
    });
    password?.addEventListener("input", () => {
      const value = password.value;
      const score = [value.length >= 8, /[A-ZА-Я]/.test(value) && /[a-zа-я]/.test(value), /\d/.test(value), /[^\wа-яА-Я]/.test(value)].filter(Boolean).length;
      form.dataset.passwordScore = String(score);
      passwordHint.textContent = !value ? "Минимум 8 символов" : score < 2 ? "Слабый пароль" : score < 4 ? "Хороший пароль" : "Надёжный пароль";
    });
    form?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const body = Object.fromEntries(new FormData(form).entries());
      const button = form.querySelector("button[type=submit]");
      button.disabled = true;
      status.textContent = "Создаю защищённую учётную запись…";
      try {
        await PanelAPI.post("/admin/admins", body);
        form.reset();
        PanelAPI.bust("/admin/admins");
        toast("Администратор создан", "success");
        await renderAdmins();
      } catch (error) {
        status.textContent = error.message === "admin_username_taken" ? "Этот логин уже занят." : `Ошибка: ${error.message}`;
      } finally {
        button.disabled = false;
      }
    });
  }

  async function renderUsers() {
    main.innerHTML = `
      <div class="members-page">
        <section class="members-hero">
          <div><span class="members-eyebrow">Команда Garbona</span><h1>Участники</h1><p>Профиль, статистика, ссылки и доступ — в одной карточке.</p></div>
          <button type="button" class="btn-ghost members-sync" id="syncSteamAll">Обновить настройки UProject</button>
        </section>
        <div class="member-summary-grid" id="memberSummary"><div></div><div></div><div></div><div></div></div>
        <section class="members-workspace">
          <div class="members-toolbar">
            <div class="members-search"><svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="6.5" stroke="currentColor"/><path d="m16 16 4 4" stroke="currentColor"/></svg><input id="userSearch" type="search" placeholder="Имя, @username или Telegram ID"/><kbd>Enter</kbd></div>
            <div class="members-filters"><button class="is-active" data-list="team">Все</button><button data-list="curators">Кураторы</button><button data-list="callers">Прозвон</button></div>
          </div>
          <div class="members-grid" id="usersGrid"><div class="members-loading">Загружаем команду…</div></div>
        </section>
      </div>
    `;

    async function load(mode = "team", q = "") {
      main.querySelectorAll("[data-list]").forEach((b) => b.classList.toggle("is-active", b.dataset.list === mode));
      let data;
      if (mode === "curators") data = await PanelAPI.get("/admin/members/roles/curators");
      else if (mode === "callers") data = await PanelAPI.get("/admin/members/roles/callers");
      else data = await PanelAPI.get(`/admin/members${q ? `?q=${encodeURIComponent(q)}` : ""}`);
      const members = data.members || [];
      const summary = document.getElementById("memberSummary");
      summary.innerHTML = [["Участников",members.length],["Кураторов",members.filter((m) => m.isCurator).length],["С UProject",members.filter((m) => m.panelUsername).length],["Общий баланс",`$${members.reduce((s,m) => s + Number(m.walletUsd || 0),0).toFixed(2)}`]].map(([label,value],i) => `<div><span>${label}</span><strong>${escapeHtml(value)}</strong><i class="tone-${i}"></i></div>`).join("");
      const grid = document.getElementById("usersGrid");
      grid.innerHTML = members.length ? members.map((m) => {
        const name = m.firstName || m.username || `ID ${m.telegramId}`;
        const initials = name.trim().slice(0,2).toUpperCase();
        const photo = /^https?:\/\//i.test(String(m.photoUrl || "")) ? m.photoUrl : "";
        const state = m.isBanned ? "Заблокирован" : m.isTeamMember ? "Активен" : "Вне команды";
        return `<button type="button" class="member-list-card" data-member-id="${escapeHtml(m.telegramId)}"><div class="member-list-main"><span class="member-list-avatar"><span>${escapeHtml(initials)}</span>${photo ? `<img src="${escapeHtml(photo)}" alt="" loading="lazy" referrerpolicy="no-referrer"/>` : ""}<i class="${m.isBanned ? "is-bad" : ""}"></i></span><div><b>${escapeHtml(name)}</b><small>${m.username ? `@${escapeHtml(m.username)}` : escapeHtml(m.telegramId)}</small></div><span class="member-list-chevron">→</span></div><div class="member-list-meta"><span><small>Роль</small><b>${roleOf(m)}</b></span><span><small>Процент</small><b>${m.profitPercent}%</b></span><span><small>Кошелёк</small><b>${escapeHtml(m.walletDisplay)}</b></span></div><div class="member-list-foot"><span class="${m.isBanned ? "is-bad" : ""}"><i></i>${state}</span><small>${m.panelUsername ? `UProject · ${escapeHtml(m.panelUsername)}` : "UProject не подключён"}</small></div></button>`;
      }).join("") : `<div class="members-empty"><b>Никого не нашли</b><span>Попробуйте другой запрос или фильтр.</span></div>`;
      grid.querySelectorAll(".member-list-avatar img").forEach((img) => img.addEventListener("error", () => img.remove()));
      grid.querySelectorAll("[data-member-id]").forEach((card) => card.addEventListener("click", () => openMember(card.dataset.memberId)));
    }

    document.getElementById("userSearch").addEventListener("keydown", (e) => {
      if (e.key === "Enter") load("team", e.currentTarget.value.trim());
    });
    main.querySelectorAll("[data-list]").forEach((b) => {
      b.addEventListener("click", () => load(b.dataset.list));
    });
    document.getElementById("syncSteamAll").addEventListener("click", async (event) => {
      const button = event.currentTarget; button.disabled = true; button.textContent = "Синхронизация…";
      try { const result = await PanelAPI.post("/admin/members/steam-settings/sync-all", {}); toast(`Готово: ${result.configured + result.unchanged}, ошибок: ${result.failed}`, result.failed ? "error" : "ok"); }
      catch (error) { toast(error.message, "error"); }
      finally { button.disabled = false; button.textContent = "Обновить настройки UProject"; }
    });
    await load("team");
  }

  function roleOf(m) {
    if (m.isCurator) return "Куратор";
    if (m.isCaller) return "Прозвонщица";
    if (m.isModerator) return "Модер";
    if (m.isTeamMember) return "Воркер";
    return "—";
  }

  async function renderStats() {
    const [stats, top] = await Promise.all([
      PanelAPI.get(`/admin/stats?period=${statsPeriod}`),
      PanelAPI.get(`/admin/top?period=${statsPeriod}&limit=15`),
    ]);
    main.innerHTML = `
      <div class="greeting">
        <div>
          <h1 class="greeting-title">Статистика</h1>
          <p class="greeting-sub">Период: ${escapeHtml(stats.periodLabel)}</p>
        </div>
        <div class="period-pills" id="statsPeriods">
          ${["all", "24h", "7d", "30d"]
            .map(
              (p) =>
                `<button type="button" class="period-pill ${
                  p === statsPeriod ? "is-active" : ""
                }" data-period="${p}">${periodLabel(p)}</button>`
            )
            .join("")}
        </div>
      </div>
      <div class="stats-row">
        <div class="stat-card"><div class="stat-label">Команда</div><div class="stat-value">${stats.teamCount}</div></div>
        <div class="stat-card"><div class="stat-label">Заявки</div><div class="stat-value">${stats.applications.total}</div><div class="stat-hint">принят ${stats.applications.accepted} · откл ${stats.applications.rejected}</div></div>
        <div class="stat-card"><div class="stat-label">Профиты</div><div class="stat-value">${stats.profits.count}</div></div>
        <div class="stat-card"><div class="stat-label">Сумма</div><div class="stat-value">${escapeHtml(stats.profits.totalDisplay)}</div></div>
      </div>
      <div class="panel-card">
        <div class="panel-card-head"><h2 class="panel-card-title">Топ воркеров</h2></div>
        <div class="panel-card-body">
          <div class="table-wrap">
            <table class="data">
              <thead><tr><th>#</th><th>Воркер</th><th>Профитов</th><th>Сумма</th></tr></thead>
              <tbody id="topBody"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    const body = document.getElementById("topBody");
    (top.rows || []).forEach((r) => {
      const tr = document.createElement("tr");
      tr.className = "clickable-row";
      tr.innerHTML = `
        <td class="muted">${r.rank}</td>
        <td>${r.username ? `@${escapeHtml(r.username)}` : r.telegramId || "—"}</td>
        <td class="muted">${r.count}</td>
        <td>${escapeHtml(r.totalDisplay)}</td>
      `;
      if (r.telegramId) tr.addEventListener("click", () => openMember(r.telegramId));
      body.appendChild(tr);
    });
    if (!(top.rows || []).length) {
      body.innerHTML = `<tr><td colspan="4" class="muted">Пока пусто</td></tr>`;
    }
    document.getElementById("statsPeriods").addEventListener("click", (e) => {
      const b = e.target.closest("[data-period]");
      if (!b) return;
      statsPeriod = b.dataset.period;
      renderStats();
    });
  }

  function periodLabel(p) {
    return { all: "Всё время", "24h": "24ч", "7d": "7д", "30d": "30д" }[p] || p;
  }

  async function renderEconomy() {
    const eco = await PanelAPI.get("/admin/economy");
    main.innerHTML = `
      <div class="settings-page">
        <div class="greeting">
          <div>
            <h1 class="greeting-title">Экономика</h1>
            <p class="greeting-sub">Глобальные параметры выплат и отображения</p>
          </div>
        </div>

        <div class="settings-section">
          <div class="settings-section-label">
            <h3 class="settings-section-title">Выплаты воркерам</h3>
            <span class="settings-section-desc">Влияет на всех участников</span>
          </div>
          <div class="settings-card">
            <div class="settings-row">
              <div class="settings-row-text">
                <div class="settings-row-title">Глобальный %</div>
                <div class="settings-row-desc">Процент от профита на баланс всем воркерам</div>
              </div>
              <div class="settings-row-control">
                <div class="settings-input-wrap">
                  <input class="settings-input" id="ecoPercent" type="number" min="1" max="100" value="${eco.globalPercent}" />
                  <span class="settings-suffix">%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="settings-section">
          <div class="settings-section-label">
            <h3 class="settings-section-title">Отображение</h3>
            <span class="settings-section-desc">Только UI, балансы в USD</span>
          </div>
          <div class="settings-card">
            <div class="settings-row">
              <div class="settings-row-text">
                <div class="settings-row-title">Валюта</div>
                <div class="settings-row-desc">Формат сумм в боте и панели</div>
              </div>
              <div class="seg" id="ecoCurrency">
                <button type="button" class="seg-btn ${eco.currency === "USD" ? "is-active" : ""}" data-cur="USD">USD</button>
                <button type="button" class="seg-btn ${eco.currency === "RUB" ? "is-active" : ""}" data-cur="RUB">RUB</button>
              </div>
            </div>
            <div class="settings-row">
              <div class="settings-row-text">
                <div class="settings-row-title">Курс USD→RUB</div>
                <div class="settings-row-desc">Используется при валюте RUB</div>
              </div>
              <div class="settings-row-control">
                <div class="settings-input-wrap">
                  <input class="settings-input" id="ecoRate" type="number" min="0.01" step="0.01" value="${eco.rate}" />
                  <span class="settings-suffix">₽</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="settings-section">
          <div class="settings-section-label">
            <h3 class="settings-section-title">Имитация</h3>
            <span class="settings-section-desc">Косметические посты в каналы / ЛС</span>
          </div>
          <div class="settings-card">
            <div class="settings-card-body">
              <div class="settings-row-title">Фейк-профит</div>
              <div class="settings-row-desc">5–7 скинов CS2 + опционально баланс, MaFile-время и игры на карточке</div>
              <div class="drawer-actions" style="margin-bottom:10px;flex-wrap:wrap;gap:8px">
                <input class="search-input" id="fakeProfitBalance" type="number" min="0" step="0.01" placeholder="Баланс Steam ($)" style="max-width:160px" />
                <input class="search-input" id="fakeProfitMafile" placeholder="MaFile: часы или дата" style="max-width:180px" />
                <input class="search-input" id="fakeProfitGames" type="number" min="0" max="4" step="1" value="4" placeholder="Игр (0–4)" style="max-width:120px" />
              </div>
              <textarea class="settings-textarea" id="fakeProfitText">баланс: 300.00
mafile: 39
игры: 4
AK-47 | Redline (Field-Tested)
AWP | Asiimov (Field-Tested)
M4A1-S | Hot Rod (Factory New)
USP-S | Kill Confirmed (Minimal Wear)
Glock-18 | Fade (Factory New)</textarea>
              <div class="drawer-actions">
                <label class="check-label">
                  <input type="checkbox" class="check-input" id="fakeProfitAnon" />
                  <span class="check-box" aria-hidden="true"></span>
                  <span>Анонимно</span>
                </label>
                <input class="search-input" id="fakeProfitOwner" placeholder="Telegram ID владельца" />
                <button type="button" class="btn-primary" id="fakeProfitBtn">Отправить</button>
              </div>
            </div>
          </div>
          <div class="settings-card">
            <div class="settings-card-body">
              <div class="settings-row-title">Фейк-лог</div>
              <div class="settings-row-desc">Лимит, баланс, инвентарь, уровень, актив, игры — по строке</div>
              <textarea class="settings-textarea" id="fakeLogText">лимит: Нет
баланс: 12.50
инвентарь: 150.00
уровень: 42
актив: 2024-08-15
игры: 8</textarea>
              <div class="drawer-actions">
                <input class="search-input" id="fakeLogOwner" placeholder="Telegram ID получателя" />
                <button type="button" class="btn-primary" id="fakeLogBtn">Отправить в ЛС</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    const savePercent = debounce(async () => {
      try {
        await PanelAPI.patch("/admin/economy", {
          globalPercent: Number(document.getElementById("ecoPercent").value),
        });
        toast("Глобальный % сохранён");
      } catch (e) {
        toast(e.message, "error");
      }
    }, 400);

    const saveRate = debounce(async () => {
      try {
        await PanelAPI.patch("/admin/economy", {
          rate: Number(document.getElementById("ecoRate").value),
        });
        toast("Курс сохранён");
      } catch (e) {
        toast(e.message, "error");
      }
    }, 400);

    document.getElementById("ecoPercent").addEventListener("change", savePercent);
    document.getElementById("ecoPercent").addEventListener("input", savePercent);
    document.getElementById("ecoRate").addEventListener("change", saveRate);
    document.getElementById("ecoRate").addEventListener("input", saveRate);

    document.getElementById("ecoCurrency").addEventListener("click", async (e) => {
      const b = e.target.closest("[data-cur]");
      if (!b) return;
      try {
        await PanelAPI.patch("/admin/economy", { currency: b.dataset.cur });
        toast(`Валюта: ${b.dataset.cur}`);
        renderEconomy();
      } catch (err) {
        toast(err.message, "error");
      }
    });

    document.getElementById("fakeProfitBtn").addEventListener("click", async () => {
      try {
        await PanelAPI.post("/admin/economy/fake-profit", {
          text: document.getElementById("fakeProfitText").value,
          balanceUsd: document.getElementById("fakeProfitBalance").value,
          mafileTime: document.getElementById("fakeProfitMafile").value.trim(),
          gamesCount: document.getElementById("fakeProfitGames").value,
          anonymous: document.getElementById("fakeProfitAnon").checked,
          ownerTelegramId: document.getElementById("fakeProfitOwner").value.trim(),
        });
        toast("Фейк-профит отправлен");
      } catch (e) {
        toast(e.message, "error");
      }
    });

    document.getElementById("fakeLogBtn").addEventListener("click", async () => {
      try {
        await PanelAPI.post("/admin/economy/fake-log", {
          text: document.getElementById("fakeLogText").value,
          ownerTelegramId: document.getElementById("fakeLogOwner").value.trim(),
        });
        toast("Фейк-лог отправлен");
      } catch (e) {
        toast(e.message, "error");
      }
    });
  }

  async function renderApps() {
    const data = await PanelAPI.get(`/admin/apps?kind=${appsKind}&page=${appsPage}`, { force: true });
    const labels = new Map((data.questions || []).map((q) => [q.key, q.label]));
    const statusLabel = (status) => ({ pending: "На рассмотрении", accepted: "Принята", rejected: "Отклонена" }[status] || status);
    main.innerHTML = `
      <div class="applications-page">
        <section class="applications-hero"><div><span>Набор в команду</span><h1>Заявки</h1><p>Спокойная очередь решений: ответы, контекст и действия без таблиц.</p></div><div class="applications-switch"><button class="${appsKind === "pending" ? "is-active" : ""}" data-kind="pending">Очередь <b>${data.counts?.pending || 0}</b></button><button class="${appsKind === "closed" ? "is-active" : ""}" data-kind="closed">История <b>${(data.counts?.accepted || 0) + (data.counts?.rejected || 0)}</b></button></div></section>
        <div class="application-summary"><div><span>Ожидают решения</span><strong>${data.counts?.pending || 0}</strong><i class="is-wait"></i></div><div><span>Принято</span><strong>${data.counts?.accepted || 0}</strong><i class="is-ok"></i></div><div><span>Отклонено</span><strong>${data.counts?.rejected || 0}</strong><i class="is-bad"></i></div></div>
        <div class="application-list" id="appsBody"></div>
        ${data.totalPages > 1 ? `<nav class="application-pagination"><button id="appsPrev" ${appsPage <= 0 ? "disabled" : ""}>← Назад</button><span>${appsPage + 1} / ${data.totalPages}</span><button id="appsNext" ${appsPage >= data.totalPages - 1 ? "disabled" : ""}>Дальше →</button></nav>` : ""}
      </div>
    `;
    const body = document.getElementById("appsBody");
    const decideApp = async (id, action, { confirmText } = {}) => {
      if (confirmText && !(await GarbonaAdminConfirm.open(confirmText, { confirmLabel: "Отклонить" }))) return;
      try {
        const result = await PanelAPI.post(`/admin/apps/${id}/decide`, { action });
        toast(
          result?.reversed
            ? action === "accept"
              ? "Решение изменено: принята"
              : "Решение изменено: отклонена"
            : action === "accept"
              ? "Принято"
              : "Отклонено"
        );
        PanelAPI.bust("/admin/apps"); renderApps();
      } catch (e) {
        toast(e.message, "error");
      }
    };
    body.innerHTML = (data.apps || []).length ? data.apps.map((a) => {
      const name = a.firstName || a.username || `ID ${a.telegramId || "—"}`;
      const answers = Object.entries(a.answers || {});
      return `<article class="application-card ${a.status !== "pending" ? "is-closed" : ""}"><header><div class="application-person"><span>${escapeHtml(name.trim().slice(0,2).toUpperCase())}</span><div><h2>${escapeHtml(name)}</h2><p>${a.username ? `@${escapeHtml(a.username)}` : escapeHtml(a.telegramId || "Без Telegram ID")}</p></div></div><div class="application-state ${a.status}"><i></i>${statusLabel(a.status)}</div></header><div class="application-meta"><span>Заявка <code>#${escapeHtml(a.id.slice(-6))}</code></span><span>${new Date(a.createdAt).toLocaleString("ru-RU", { day:"2-digit", month:"long", hour:"2-digit", minute:"2-digit" })}</span>${a.moderatorId ? `<span>Модератор <code>${escapeHtml(a.moderatorId)}</code></span>` : ""}</div><div class="application-answers">${answers.length ? answers.map(([key,value],index) => `<div class="${index === 0 && answers.length > 2 ? "is-wide" : ""}"><span>${escapeHtml(labels.get(key) || key)}</span><p>${escapeHtml(value || "—")}</p></div>`).join("") : `<div class="is-wide"><span>Ответы</span><p>Не заполнены</p></div>`}</div><footer><div class="application-actions">${a.status === "pending" ? `<button class="btn-primary" data-app-action="accept" data-app-id="${a.id}">Принять в команду</button><button class="btn-ghost btn-danger" data-app-action="reject" data-app-id="${a.id}">Отклонить</button>` : a.status === "rejected" ? `<button class="btn-primary" data-app-action="accept" data-app-id="${a.id}">Изменить → принять</button>` : `<button class="btn-ghost btn-danger" data-app-action="reject" data-app-id="${a.id}" data-reverse="1">Изменить → отклонить</button>`}</div>${a.telegramId ? `<button class="application-profile" data-app-member="${escapeHtml(a.telegramId)}">Открыть профиль <b>→</b></button>` : ""}</footer></article>`;
    }).join("") : `<div class="applications-empty"><span>✓</span><b>${appsKind === "pending" ? "Очередь разобрана" : "История пока пуста"}</b><p>${appsKind === "pending" ? "Новых заявок сейчас нет." : "Здесь появятся принятые и отклонённые заявки."}</p></div>`;
    body.querySelectorAll("[data-app-action]").forEach((button) => button.addEventListener("click", () => decideApp(button.dataset.appId, button.dataset.appAction, button.dataset.reverse ? { confirmText:"Отклонить принятую заявку? Пользователь будет исключён из команды." } : {})));
    body.querySelectorAll("[data-app-member]").forEach((button) => button.addEventListener("click", () => openMember(button.dataset.appMember)));
    main.querySelectorAll("[data-kind]").forEach((b) => {
      b.addEventListener("click", () => {
        appsKind = b.dataset.kind; appsPage = 0;
        renderApps();
      });
    });
    document.getElementById("appsPrev")?.addEventListener("click", () => { appsPage = Math.max(0, appsPage - 1); renderApps(); });
    document.getElementById("appsNext")?.addEventListener("click", () => { appsPage += 1; renderApps(); });
  }

  async function renderComms() {
    let recipients = { count: 0 };
    try {
      recipients = await PanelAPI.get("/admin/comms/recipients");
    } catch (_) {
      /* ignore */
    }
    main.innerHTML = `
      <div class="settings-page">
        <div class="greeting">
          <div>
            <h1 class="greeting-title">Коммуникация</h1>
            <p class="greeting-sub">Получателей рассылки: ${recipients.count}</p>
          </div>
        </div>
        <div class="settings-section">
          <div class="settings-section-label">
            <h3 class="settings-section-title">Рассылка</h3>
            <span class="settings-section-desc">Текст всем участникам команды в Telegram</span>
          </div>
          <div class="settings-card">
            <div class="settings-card-body">
              <textarea class="settings-textarea" id="broadcastText" placeholder="HTML-текст…"></textarea>
              <button type="button" class="btn-primary" id="broadcastBtn">Отправить</button>
            </div>
          </div>
        </div>
        <div class="settings-section">
          <div class="settings-section-label">
            <h3 class="settings-section-title">Уведомление в панель</h3>
            <span class="settings-section-desc">WebApp и сайт · колокольчик у воркеров</span>
          </div>
          <div class="settings-card">
            <div class="settings-card-body comms-panel-notify">
              <label class="settings-field">
                <span class="settings-field-label">Заголовок</span>
                <input type="text" class="settings-input" id="panelNotifyTitle" maxlength="120" placeholder="Например: Обновление правил" />
              </label>
              <label class="settings-field">
                <span class="settings-field-label">Текст (HTML)</span>
                <textarea class="settings-textarea" id="panelNotifyMessage" placeholder="Поддерживаются &lt;b&gt;, &lt;i&gt;, &lt;u&gt;, &lt;code&gt;, &lt;a href=&quot;…&quot;&gt;"></textarea>
              </label>
              <div class="comms-panel-notify-row">
                <label class="settings-field">
                  <span class="settings-field-label">Важность</span>
                  <select class="settings-input" id="panelNotifySeverity">
                    <option value="info">Информация</option>
                    <option value="warn">Внимание</option>
                    <option value="danger">Важно</option>
                  </select>
                </label>
                <label class="settings-field">
                  <span class="settings-field-label">При клике</span>
                  <select class="settings-input" id="panelNotifyLinkType">
                    <option value="none">Никуда</option>
                    <option value="view">Раздел панели</option>
                    <option value="url">Внешняя ссылка</option>
                    <option value="domain">Домен (сайты)</option>
                  </select>
                </label>
              </div>
              <label class="settings-field" id="panelNotifyLinkViewWrap" hidden>
                <span class="settings-field-label">Раздел</span>
                <select class="settings-input" id="panelNotifyLinkView">
                  <option value="dashboard">Главная</option>
                  <option value="sites">Сайты</option>
                  <option value="analytics">Аналитика</option>
                  <option value="top">Топ</option>
                  <option value="wallet">Кошелёк</option>
                  <option value="settings">Настройки</option>
                  <option value="support">Поддержка</option>
                </select>
              </label>
              <label class="settings-field" id="panelNotifyLinkUrlWrap" hidden>
                <span class="settings-field-label">URL</span>
                <input type="url" class="settings-input" id="panelNotifyLinkUrl" placeholder="https://…" />
              </label>
              <label class="settings-field" id="panelNotifyLinkDomainWrap" hidden>
                <span class="settings-field-label">ID домена</span>
                <input type="number" class="settings-input" id="panelNotifyLinkDomain" min="1" placeholder="123" />
              </label>
              <button type="button" class="btn-primary" id="panelNotifyBtn">Отправить в панель</button>
            </div>
          </div>
        </div>
        <div class="settings-section">
          <div class="settings-section-label">
            <h3 class="settings-section-title">Динамический закреп</h3>
            <span class="settings-section-desc">Чат воркеров · автообновление</span>
          </div>
          <div class="settings-card">
            <div class="settings-row">
              <div class="settings-row-text">
                <div class="settings-row-title">Обновить Live Pin</div>
                <div class="settings-row-desc">Стафф, профиты сегодня, курс, статус API</div>
              </div>
              <button type="button" class="btn-primary" id="dynamicPinBtn">Обновить</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const linkTypeEl = document.getElementById("panelNotifyLinkType");
    const linkViewWrap = document.getElementById("panelNotifyLinkViewWrap");
    const linkUrlWrap = document.getElementById("panelNotifyLinkUrlWrap");
    const linkDomainWrap = document.getElementById("panelNotifyLinkDomainWrap");

    function syncPanelNotifyLinkFields() {
      const type = linkTypeEl?.value || "none";
      if (linkViewWrap) linkViewWrap.hidden = type !== "view";
      if (linkUrlWrap) linkUrlWrap.hidden = type !== "url";
      if (linkDomainWrap) linkDomainWrap.hidden = type !== "domain";
    }
    linkTypeEl?.addEventListener("change", syncPanelNotifyLinkFields);
    syncPanelNotifyLinkFields();

    document.getElementById("broadcastBtn").addEventListener("click", async () => {
      if (!(await GarbonaAdminConfirm.open("Отправить рассылку всем?", { confirmLabel: "Отправить" }))) return;
      try {
        const result = await PanelAPI.post("/admin/comms/broadcast", {
          text: document.getElementById("broadcastText").value,
        });
        toast(`Готово: ${JSON.stringify(result.result || result)}`);
      } catch (e) {
        toast(e.message, "error");
      }
    });

    document.getElementById("panelNotifyBtn").addEventListener("click", async () => {
      if (!(await GarbonaAdminConfirm.open("Отправить уведомление всем воркерам в панели?", { confirmLabel: "Отправить" }))) return;
      const linkType = linkTypeEl?.value || "none";
      const payload = {
        title: document.getElementById("panelNotifyTitle")?.value || "",
        messageHtml: document.getElementById("panelNotifyMessage")?.value || "",
        severity: document.getElementById("panelNotifySeverity")?.value || "info",
        linkType,
      };
      if (linkType === "view") {
        payload.linkView = document.getElementById("panelNotifyLinkView")?.value || "";
      } else if (linkType === "url") {
        payload.linkUrl = document.getElementById("panelNotifyLinkUrl")?.value || "";
      } else if (linkType === "domain") {
        payload.linkDomainId = document.getElementById("panelNotifyLinkDomain")?.value || "";
      }
      try {
        const data = await PanelAPI.post("/admin/comms/panel-notify", payload);
        toast(`Уведомление отправлено · ${data.notification?.title || "ok"}`);
        document.getElementById("panelNotifyTitle").value = "";
        document.getElementById("panelNotifyMessage").value = "";
      } catch (e) {
        toast(e.message, "error");
      }
    });

    document.getElementById("dynamicPinBtn").addEventListener("click", async () => {
      try {
        const data = await PanelAPI.post("/admin/comms/dynamic-pin", {});
        const r = data.result || data;
        toast(`Live Pin · ${r.refreshed ? "обновлён" : "создан"} · ${r.messageId || "ok"}`);
      } catch (e) {
        toast(e.message, "error");
      }
    });
  }

  async function renderPayouts() {
    const data = await PanelAPI.get("/admin/payouts?status=open");
    main.innerHTML = `
      <div class="greeting">
        <div>
          <h1 class="greeting-title">Выплаты</h1>
          <p class="greeting-sub">Очередь модерации</p>
        </div>
      </div>
      <div class="panel-card">
        <div class="panel-card-body" style="padding-top:16px">
          <div class="table-wrap">
            <table class="data">
              <thead><tr><th>ID</th><th>Юзер</th><th>Сумма</th><th>Метод</th><th>Статус</th><th></th></tr></thead>
              <tbody id="payoutsBody"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    const body = document.getElementById("payoutsBody");
    (data.payouts || []).forEach((p) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="muted"><code>${String(p.id).slice(-6)}</code></td>
        <td>${p.telegramId || "—"}</td>
        <td>$${Number(p.amountUsd).toFixed(2)}</td>
        <td class="muted">${escapeHtml(p.method)}</td>
        <td><span class="badge wait">${p.status}</span></td>
        <td class="drawer-actions"></td>
      `;
      const cell = tr.lastElementChild;
      if (p.status === "pending") {
        const a = document.createElement("button");
        a.className = "btn-primary";
        a.textContent = "Одобрить";
        a.onclick = async () => {
          try {
            await PanelAPI.post(`/admin/payouts/${p.id}/approve`, {});
            toast("Ожидает ссылку");
            renderPayouts();
          } catch (e) {
            toast(e.message, "error");
          }
        };
        cell.appendChild(a);
      }
      if (p.status === "awaiting_payout_link") {
        const input = document.createElement("input");
        input.className = "search-input";
        input.placeholder = "https://…";
        input.style.width = "140px";
        const send = document.createElement("button");
        send.className = "btn-primary";
        send.textContent = "Ссылка";
        send.onclick = async () => {
          try {
            await PanelAPI.post(`/admin/payouts/${p.id}/link`, { url: input.value });
            toast("Выплата завершена");
            renderPayouts();
          } catch (e) {
            toast(e.message, "error");
          }
        };
        cell.append(input, send);
      }
      const rej = document.createElement("button");
      rej.className = "btn-ghost btn-danger";
      rej.textContent = "Отклонить";
      rej.onclick = async () => {
        try {
          await PanelAPI.post(`/admin/payouts/${p.id}/reject`, {});
          toast("Отклонено");
          renderPayouts();
        } catch (e) {
          toast(e.message, "error");
        }
      };
      cell.appendChild(rej);
      if (p.telegramId) {
        const card = document.createElement("button");
        card.className = "btn-ghost";
        card.textContent = "Юзер";
        card.onclick = () => openMember(p.telegramId);
        cell.appendChild(card);
      }
      body.appendChild(tr);
    });
    if (!(data.payouts || []).length) {
      body.innerHTML = `<tr><td colspan="6" class="muted">Очередь пуста</td></tr>`;
    }
  }

  async function renderSites() {
    let sitesTab = "referrals";
    let selectedDomainId = null;

    main.innerHTML = `
      <div class="greeting">
        <div>
          <h1 class="greeting-title">Сайты</h1>
          <p class="greeting-sub" id="sitesSub">Все домены, ссылки и аналитика команды</p>
        </div>
        <div class="period-pills" id="sitesTabs">
          <button type="button" class="period-pill is-active" data-sites-tab="referrals">Рефералки</button>
          <button type="button" class="period-pill" data-sites-tab="domains">Домены</button>
          <button type="button" class="period-pill" data-sites-tab="analytics">Аналитика</button>
          <button type="button" class="period-pill" data-sites-tab="templates">Шаблоны</button>
          <button type="button" class="period-pill" data-sites-tab="workers">Воркеры</button>
        </div>
      </div>
      <div id="sitesBody"></div>
    `;

    const body = document.getElementById("sitesBody");
    const sub = document.getElementById("sitesSub");

    document.getElementById("sitesTabs").addEventListener("click", (e) => {
      const btn = e.target.closest("[data-sites-tab]");
      if (!btn) return;
      sitesTab = btn.dataset.sitesTab;
      selectedDomainId = null;
      document.querySelectorAll("#sitesTabs .period-pill").forEach((el) => {
        el.classList.toggle("is-active", el.dataset.sitesTab === sitesTab);
      });
      load();
    });

    async function load() {
      body.innerHTML = `<div class="panel-card"><div class="panel-card-body"><div class="muted">Загрузка…</div></div></div>`;
      try {
        if (sitesTab === "workers") await renderWorkers();
        else if (sitesTab === "templates") await renderTemplatesVisibility();
        else if (sitesTab === "analytics") await renderSiteAnalytics();
        else if (sitesTab === "referrals") await renderReferrals();
        else if (selectedDomainId) await renderDomainDetail(selectedDomainId);
        else await renderDomains();
      } catch (e) {
        body.innerHTML = `
          <div class="panel-card">
            <div class="panel-card-body">
              <div class="empty">
                <div class="empty-title">Не удалось открыть сайты</div>
                <div class="empty-sub">${escapeHtml(e.message)}</div>
              </div>
            </div>
          </div>`;
      }
    }

    async function renderReferrals() {
      const data = await PanelAPI.get("/admin/sites/referrals", { force: true });
      const templates = data.templates || [];
      sub.textContent = `Реферальных ссылок: ${data.total || 0}`;
      body.innerHTML = `
        <div class="panel-card">
          <div class="panel-card-body" style="padding-top:16px">
            <div class="search-row" style="margin-bottom:12px">
              <input class="search-input" id="refSearch" placeholder="Поиск: @user, telegram id, path, домен" />
            </div>
            <div class="table-wrap">
              <table class="data">
                <thead>
                  <tr>
                    <th>Воркер</th>
                    <th>Домен</th>
                    <th>Ссылка</th>
                    <th>Шаблон</th>
                    <th>Окно</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody id="refsBody"></tbody>
              </table>
            </div>
          </div>
        </div>
      `;
      const tbody = document.getElementById("refsBody");
      const rows = data.referrals || [];

      const paint = (filter = "") => {
        tbody.innerHTML = "";
        const q = String(filter || "").trim().toLowerCase();
        const filtered = !q
          ? rows
          : rows.filter((r) =>
              [r.username, r.telegramId, r.customId, r.domainName, r.path, r.url]
                .map((v) => String(v || "").toLowerCase())
                .join(" ")
                .includes(q)
            );
        if (!filtered.length) {
          tbody.innerHTML = `<tr><td colspan="6" class="muted">Пусто</td></tr>`;
          return;
        }
        filtered.forEach((r) => {
          const tr = document.createElement("tr");
          const tplOptions = templates
            .map(
              (t) =>
                `<option value="${t.id}">${escapeHtml(t.name || `Template #${t.id}`)} (#${t.id})</option>`
            )
            .join("");
          tr.innerHTML = `
            <td>
              ${r.username ? `@${escapeHtml(r.username)}` : "—"}
              <div class="muted"><code>${escapeHtml(r.telegramId)}</code></div>
            </td>
            <td>${escapeHtml(r.domainName || `#${r.domainId}`)}</td>
            <td><code style="word-break:break-all">${escapeHtml(r.url || r.path || "—")}</code></td>
            <td>
              <select class="search-input ref-template" style="min-width:160px;max-width:220px">
                <option value="">Шаблон…</option>
                ${tplOptions}
              </select>
            </td>
            <td>
              <select class="search-input ref-window" style="min-width:140px">
                <option value="">Окно…</option>
                <option value="FakeWindow">FakeWindow</option>
                <option value="CurrentWindow">CurrentWindow</option>
                <option value="NewWindow">NewWindow</option>
                <option value="AboutBlank">AboutBlank</option>
              </select>
            </td>
            <td class="drawer-actions"></td>
          `;
          const cell = tr.lastElementChild;
          const save = document.createElement("button");
          save.className = "btn-primary";
          save.textContent = "Сохранить";
          save.onclick = async () => {
            const templateId = tr.querySelector(".ref-template").value;
            const windowType = tr.querySelector(".ref-window").value;
            if (!templateId && !windowType) {
              toast("Выберите шаблон или окно", "error");
              return;
            }
            try {
              await PanelAPI.patch(`/admin/sites/referrals/${r.telegramId}/${r.domainId}`, {
                templateId: templateId || undefined,
                windowType: windowType || undefined,
              });
              toast("Обновлено");
            } catch (e) {
              toast(e.message, "error");
            }
          };
          const del = document.createElement("button");
          del.className = "btn-ghost btn-danger";
          del.textContent = "Удалить";
          del.onclick = async () => {
            if (
              !(await GarbonaAdminConfirm.open(
                `Удалить рефералку ${r.username ? "@" + r.username : r.telegramId} на ${r.domainName || r.domainId}?`,
                { confirmLabel: "Удалить" }
              ))
            ) {
              return;
            }
            try {
              await PanelAPI.del(`/admin/sites/referrals/${r.telegramId}/${r.domainId}`);
              toast("Удалено");
              await renderReferrals();
            } catch (e) {
              toast(e.message, "error");
            }
          };
          const open = document.createElement("button");
          open.className = "btn-ghost";
          open.textContent = "Карточка";
          open.onclick = () => openMember(r.telegramId);
          cell.append(save, del, open);
          tbody.appendChild(tr);
        });
      };

      paint();
      document.getElementById("refSearch").addEventListener("input", (e) => paint(e.target.value));
    }

    async function renderDomains() {
      const data = await PanelAPI.get("/admin/sites/domains");
      const domains = data.domains || [];
      sub.textContent = `Все домены команды · ${domains.length} · онлайн ${data.totalOnline || 0}`;
      body.innerHTML = `
        <div class="panel-card">
          <div class="panel-card-body" style="padding-top:16px">
            <div class="meta-grid" style="margin-bottom:16px">
              <div><dt>Домены</dt><dd>${domains.length}</dd></div>
              <div><dt>Онлайн</dt><dd>${data.totalOnline || 0}</dd></div>
              <div><dt>Просмотры</dt><dd>${data.totalViews || 0}</dd></div>
              <div><dt>Логи</dt><dd>${data.totalLogs || 0}</dd></div>
            </div>
            <div class="search-row">
              <input class="search-input" id="siteDomainInput" placeholder="новый-домен.com" />
              <button type="button" class="btn-ghost" id="siteDomainCheck">Проверить</button>
              <button type="button" class="btn-primary" id="siteDomainAdd">Добавить</button>
            </div>
            <div class="muted" id="siteDomainHint" style="margin-bottom:12px"></div>
            <div class="search-row" style="margin-bottom:12px">
              <input class="search-input" id="siteDomainSearch" placeholder="Поиск: домен, владелец, id" />
            </div>
            <div class="table-wrap">
              <table class="data">
                <thead>
                  <tr>
                    <th>Домен</th>
                    <th>Владелец</th>
                    <th>Онлайн</th>
                    <th>Просмотры</th>
                    <th>Клики</th>
                    <th>Логи</th>
                    <th>Ссылки</th>
                    <th>Тип</th>
                  </tr>
                </thead>
                <tbody id="sitesDomainsBody"></tbody>
              </table>
            </div>
          </div>
        </div>
      `;
      const tbody = document.getElementById("sitesDomainsBody");
      const paint = (filter = "") => {
        tbody.innerHTML = "";
        const q = String(filter || "").trim().toLowerCase();
        const rows = !q
          ? domains
          : domains.filter((d) =>
              [d.domain, d.ownerLabel, d.ownerTelegramId, d.ownerPanelUsername, d.id]
                .map((v) => String(v || "").toLowerCase())
                .join(" ")
                .includes(q)
            );
        rows.forEach((d) => {
          const tr = document.createElement("tr");
          tr.className = "clickable-row";
          tr.innerHTML = `
            <td>${escapeHtml(d.domain)}</td>
            <td>${escapeHtml(d.ownerLabel || "—")}</td>
            <td>${d.online || 0}</td>
            <td>${d.stats?.views || 0}</td>
            <td>${d.stats?.clicks || 0}</td>
            <td>${d.stats?.logs || 0}</td>
            <td>${d.linksCount || 0}</td>
            <td class="muted">${d.isOwn ? "свой" : d.isTeamPublic ? "командный" : "воркера"}</td>
          `;
          tr.addEventListener("click", () => {
            selectedDomainId = d.id;
            load();
          });
          tbody.appendChild(tr);
        });
        if (!rows.length) {
          tbody.innerHTML = `<tr><td colspan="8" class="muted">Доменов нет</td></tr>`;
        }
      };
      paint();
      document.getElementById("siteDomainSearch").addEventListener("input", (e) => paint(e.target.value));

      const hint = document.getElementById("siteDomainHint");
      document.getElementById("siteDomainCheck").addEventListener("click", async () => {
        try {
          const domain = document.getElementById("siteDomainInput").value.trim();
          const preview = await PanelAPI.post("/admin/sites/domains/check", { domain });
          if (preview.existing) {
            hint.textContent = `${preview.message || "Домен уже в команде"} · ${preview.existing.domain || domain}`;
            toast("Домен уже есть в команде — открываю");
            selectedDomainId = preview.existing.id || null;
            if (selectedDomainId) await load();
            return;
          }
          hint.textContent = `Свободен. A-запись → ${preview.ip || "—"}`;
          toast("Домен свободен");
        } catch (e) {
          hint.textContent = e.message;
          toast(e.message, "error");
        }
      });
      document.getElementById("siteDomainAdd").addEventListener("click", async () => {
        try {
          const domain = document.getElementById("siteDomainInput").value.trim();
          const result = await PanelAPI.post("/admin/sites/domains", { domain });
          toast(
            result.existing
              ? `Уже есть ${result.created?.domain || domain}`
              : `Добавлен ${result.created?.domain || domain}`
          );
          selectedDomainId = result.created?.id || null;
          await load();
        } catch (e) {
          toast(e.message, "error");
        }
      });
    }

    async function renderDomainDetail(domainId) {
      const [detail, templatesData] = await Promise.all([
        PanelAPI.get(`/admin/sites/domains/${domainId}`),
        PanelAPI.get("/admin/sites/templates").catch(() => ({ templates: [] })),
      ]);
      const d = detail.domain;
      sub.textContent = d.domain;
      const templates = templatesData.templates || [];
      body.innerHTML = `
        <div class="panel-card">
          <div class="panel-card-head">
            <h2 class="panel-card-title">${escapeHtml(d.domain)}</h2>
            <button type="button" class="panel-card-link" id="sitesBack">← К списку</button>
          </div>
          <div class="panel-card-body">
            <div class="meta-grid" style="margin-bottom:16px">
              <div><dt>ID</dt><dd>${d.id}</dd></div>
              <div><dt>Владелец</dt><dd>${escapeHtml(d.ownerLabel || "—")}</dd></div>
              <div><dt>Онлайн</dt><dd>${d.online || 0}</dd></div>
              <div><dt>Просмотры</dt><dd>${d.stats?.views || 0}</dd></div>
              <div><dt>Клики</dt><dd>${d.stats?.clicks || 0}</dd></div>
              <div><dt>Логи</dt><dd>${d.stats?.logs || 0}</dd></div>
              <div><dt>Тип</dt><dd>${d.isOwn ? "свой" : d.isTeamPublic ? "командный" : "воркера"}</dd></div>
              <div><dt>IP</dt><dd>${escapeHtml(d.ip || "—")}</dd></div>
            </div>
            <div class="settings-row-title" style="margin-bottom:8px">Создать ссылку</div>
            <div class="search-row">
              <input class="search-input" id="siteLinkPath" placeholder="path (пусто = random)" />
              <select class="search-input" id="siteLinkTemplate" style="max-width:220px">
                <option value="">${templates.length ? "Шаблон…" : "Нет доступных шаблонов"}</option>
                ${templates
                  .map(
                    (t) =>
                      `<option value="${t.id}">${escapeHtml(t.name || `Template #${t.id}`)} (#${t.id})</option>`
                  )
                  .join("")}
              </select>
              <select class="search-input" id="siteLinkWindow" style="max-width:160px">
                <option value="FakeWindow">FakeWindow</option>
                <option value="CurrentWindow">CurrentWindow</option>
                <option value="NewWindow">NewWindow</option>
                <option value="AboutBlank">AboutBlank</option>
              </select>
              <button type="button" class="btn-primary" id="siteLinkCreate">Создать</button>
            </div>
            <div class="table-wrap" style="margin-top:8px">
              <table class="data">
                <thead><tr><th>Path</th><th>Окно</th><th>Шаблон</th><th>Онлайн</th><th>Просмотры</th><th>Клики</th><th>Логи</th><th>ID</th></tr></thead>
                <tbody id="siteLinksBody"></tbody>
              </table>
            </div>
            <div class="settings-row-title" style="margin:20px 0 8px">Рефералки воркеров</div>
            <div class="table-wrap">
              <table class="data">
                <thead><tr><th>Воркер</th><th>Ссылка</th><th></th></tr></thead>
                <tbody id="siteRefsBody"></tbody>
              </table>
            </div>
            ${d.isOwn ? `<div class="drawer-actions" style="margin-top:16px"><button type="button" class="btn-ghost btn-danger" id="siteDomainDelete">Удалить домен</button></div>` : ""}
          </div>
        </div>
      `;
      const linksBody = document.getElementById("siteLinksBody");
      (detail.links || []).forEach((link) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>/${escapeHtml(link.path || "")}</td>
          <td class="muted">${escapeHtml(link.windowType || "—")}</td>
          <td class="muted">${escapeHtml(link.templateName || link.template || "—")}</td>
          <td>${link.online || 0}</td>
          <td>${link.stats?.views || 0}</td>
          <td>${link.stats?.clicks || 0}</td>
          <td>${link.stats?.logs || 0}</td>
          <td class="muted">${link.id ?? "—"}</td>
        `;
        linksBody.appendChild(tr);
      });
      if (!(detail.links || []).length) {
        linksBody.innerHTML = `<tr><td colspan="8" class="muted">Ссылок нет</td></tr>`;
      }

      const refsBody = document.getElementById("siteRefsBody");
      (detail.referrals || []).forEach((r) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${r.username ? `@${escapeHtml(r.username)}` : escapeHtml(r.telegramId)}</td>
          <td><code style="word-break:break-all">${escapeHtml(r.url || r.path || "—")}</code></td>
          <td class="drawer-actions"></td>
        `;
        const del = document.createElement("button");
        del.className = "btn-ghost btn-danger";
        del.textContent = "Удалить";
        del.onclick = async () => {
          if (!(await GarbonaAdminConfirm.open(`Удалить рефералку ${r.username ? "@" + r.username : r.telegramId}?`, { confirmLabel: "Удалить" }))) return;
          try {
            await PanelAPI.del(`/admin/sites/referrals/${r.telegramId}/${r.domainId}`);
            toast("Удалено");
            await renderDomainDetail(domainId);
          } catch (e) {
            toast(e.message, "error");
          }
        };
        tr.lastElementChild.appendChild(del);
        refsBody.appendChild(tr);
      });
      if (!(detail.referrals || []).length) {
        refsBody.innerHTML = `<tr><td colspan="3" class="muted">Рефералок на этом домене нет</td></tr>`;
      }

      document.getElementById("sitesBack").addEventListener("click", () => {
        selectedDomainId = null;
        load();
      });
      document.getElementById("siteLinkCreate").addEventListener("click", async () => {
        try {
          await PanelAPI.post(`/admin/sites/domains/${domainId}/links`, {
            path: document.getElementById("siteLinkPath").value.trim(),
            templateId: document.getElementById("siteLinkTemplate").value,
            windowType: document.getElementById("siteLinkWindow").value,
          });
          toast("Ссылка создана");
          await renderDomainDetail(domainId);
        } catch (e) {
          toast(e.message, "error");
        }
      });
      document.getElementById("siteDomainDelete")?.addEventListener("click", async () => {
        if (!(await GarbonaAdminConfirm.open(`Удалить домен ${d.domain}?`, { confirmLabel: "Удалить" }))) return;
        try {
          await PanelAPI.del(`/admin/sites/domains/${domainId}`);
          toast("Домен удалён");
          selectedDomainId = null;
          await load();
        } catch (e) {
          toast(e.message, "error");
        }
      });
    }

    async function renderSiteAnalytics() {
      const data = await PanelAPI.get("/admin/sites/analytics");
      const summary = data.summary || {};
      const rows = data.rows || [];
      sub.textContent = `Аналитика всех сайтов · ссылок ${summary.links || 0}`;
      body.innerHTML = `
        <div class="panel-card">
          <div class="panel-card-body" style="padding-top:16px">
            <div class="meta-grid" style="margin-bottom:16px">
              <div><dt>Домены</dt><dd>${summary.domains || 0}</dd></div>
              <div><dt>Ссылки</dt><dd>${summary.links || 0}</dd></div>
              <div><dt>Онлайн</dt><dd>${summary.online || 0}</dd></div>
              <div><dt>Просмотры</dt><dd>${summary.views || 0}</dd></div>
              <div><dt>Клики</dt><dd>${summary.clicks || 0}</dd></div>
              <div><dt>Авторизации</dt><dd>${summary.auths || 0}</dd></div>
              <div><dt>Логи</dt><dd>${summary.logs || 0}</dd></div>
              <div><dt>MaFile</dt><dd>${summary.mafiles || 0}</dd></div>
            </div>
            <div class="search-row" style="margin-bottom:12px">
              <input class="search-input" id="siteAnalyticsSearch" placeholder="Поиск: ссылка, домен, владелец" />
            </div>
            <div class="table-wrap">
              <table class="data">
                <thead>
                  <tr>
                    <th>Ссылка</th>
                    <th>Владелец</th>
                    <th>Онлайн</th>
                    <th>Просмотры</th>
                    <th>Клики</th>
                    <th>Логи</th>
                    <th>MaFile</th>
                  </tr>
                </thead>
                <tbody id="siteAnalyticsBody"></tbody>
              </table>
            </div>
          </div>
        </div>
      `;
      const tbody = document.getElementById("siteAnalyticsBody");
      const paint = (filter = "") => {
        tbody.innerHTML = "";
        const q = String(filter || "").trim().toLowerCase();
        const filtered = !q
          ? rows
          : rows.filter((r) =>
              [r.url, r.domainName, r.ownerLabel, r.ownerTelegramId, r.link?.path]
                .map((v) => String(v || "").toLowerCase())
                .join(" ")
                .includes(q)
            );
        filtered.forEach((r) => {
          const tr = document.createElement("tr");
          tr.className = "clickable-row";
          tr.innerHTML = `
            <td><code style="word-break:break-all">${escapeHtml(r.url || "—")}</code></td>
            <td>${escapeHtml(r.ownerLabel || "—")}</td>
            <td>${r.link?.online || 0}</td>
            <td>${r.link?.stats?.views || 0}</td>
            <td>${r.link?.stats?.clicks || 0}</td>
            <td>${r.link?.stats?.logs || 0}</td>
            <td>${r.link?.stats?.mafiles || 0}</td>
          `;
          tr.addEventListener("click", () => {
            if (!r.domainId) return;
            sitesTab = "domains";
            selectedDomainId = r.domainId;
            document.querySelectorAll("#sitesTabs .period-pill").forEach((el) => {
              el.classList.toggle("is-active", el.dataset.sitesTab === "domains");
            });
            load();
          });
          tbody.appendChild(tr);
        });
        if (!filtered.length) {
          tbody.innerHTML = `<tr><td colspan="7" class="muted">Ссылок нет</td></tr>`;
        }
      };
      paint();
      document.getElementById("siteAnalyticsSearch").addEventListener("input", (e) => paint(e.target.value));
    }

    async function renderWorkers() {
      const data = await PanelAPI.get("/admin/sites/workers");
      sub.textContent = `Воркеры uproject · ${data.workers?.length || 0}`;
      body.innerHTML = `
        <div class="panel-card">
          <div class="panel-card-body" style="padding-top:16px">
            <div class="table-wrap">
              <table class="data">
                <thead><tr><th>Логин</th><th>Telegram</th><th>ID</th><th></th></tr></thead>
                <tbody id="siteWorkersBody"></tbody>
              </table>
            </div>
          </div>
        </div>
      `;
      const tbody = document.getElementById("siteWorkersBody");
      (data.workers || []).forEach((w) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${escapeHtml(w.username || "—")}${w.isOwner ? ' <span class="badge ok">вы</span>' : ""}</td>
          <td class="muted">${escapeHtml(w.telegram || "—")}</td>
          <td class="muted">${w.id ?? "—"}</td>
          <td></td>
        `;
        if (w.telegram) {
          const btn = document.createElement("button");
          btn.type = "button";
          btn.className = "btn-ghost";
          btn.textContent = "Юзер";
          btn.addEventListener("click", () => openMember(String(w.telegram)));
          tr.lastElementChild.appendChild(btn);
        }
        tbody.appendChild(tr);
      });
      if (!(data.workers || []).length) {
        tbody.innerHTML = `<tr><td colspan="4" class="muted">Пусто</td></tr>`;
      }
    }

    async function renderTemplatesVisibility() {
      await mountTemplatesVisibility(body, {
        onMeta: (text) => {
          sub.textContent = text;
        },
      });
    }

    await load();
  }

  async function renderTemplates() {
    main.innerHTML = `
      <div class="greeting">
        <div>
          <h1 class="greeting-title">Шаблоны</h1>
          <p class="greeting-sub" id="templatesSub">Какие шаблоны видны в боте и панелях</p>
        </div>
      </div>
      <div id="templatesBody"></div>
    `;
    await mountTemplatesVisibility(document.getElementById("templatesBody"), {
      onMeta: (text) => {
        const el = document.getElementById("templatesSub");
        if (el) el.textContent = text;
      },
    });
  }

  async function mountTemplatesVisibility(container, { onMeta } = {}) {
    const data = await PanelAPI.get("/admin/sites/templates/visibility");
    const templates = data.templates || [];
    if (typeof onMeta === "function") onMeta(`Видимые шаблоны · ${templates.length}`);
    container.innerHTML = `
      <div class="panel-card">
        <div class="panel-card-body" style="padding-top:16px">
          <div class="settings-row-title" style="margin-bottom:4px">Добавить шаблон для воркеров</div>
          <div class="muted" style="margin-bottom:12px">
            Загрузи HTML или вставь код. Шаблон сразу появится в каталоге воркеров.
          </div>
          <div class="admin-template-create">
            <input class="search-input" id="adminTemplateName" maxlength="80" placeholder="Название шаблона" />
            <div class="admin-template-file">
              <input id="adminTemplateFile" type="file" accept=".html,text/html" hidden />
              <button type="button" class="btn-ghost" id="adminTemplateFileBtn">Выбрать .html</button>
              <span class="muted" id="adminTemplateFileName" hidden></span>
            </div>
            <textarea class="settings-textarea admin-template-code" id="adminTemplateCode" rows="8" spellcheck="false" placeholder="HTML-код шаблона"></textarea>
            <label class="admin-template-public">
              <input type="checkbox" id="adminTemplatePublic" checked />
              <span>
                <span>Сделать общедоступным для воркеров</span>
                <small class="muted">Если снять галочку, шаблон останется только у вас.</small>
              </span>
            </label>
            <div class="admin-template-create-actions">
              <button type="button" class="btn-primary" id="adminTemplateCreate">Создать шаблон</button>
              <span class="muted" id="adminTemplateHint" hidden></span>
            </div>
          </div>
          <div class="settings-row-title" style="margin:20px 0 4px">Доступные шаблоны</div>
          <div class="muted" style="margin-bottom:12px">
            Только включённые ID видны в боте и при создании ссылок${
              templates.length ? "." : ". Сейчас список пуст — шаблоны скрыты."
            }
          </div>
          <div class="search-row">
            <input class="search-input" id="siteTemplateIdInput" type="number" min="1" step="1" placeholder="ID шаблона, например 785" />
            <input class="search-input" id="siteTemplateNameInput" maxlength="80" placeholder="Своё название (необязательно)" />
            <button type="button" class="btn-primary" id="siteTemplateEnable">Включить</button>
          </div>
          <div class="table-wrap" style="margin-top:8px">
            <table class="data">
              <thead><tr><th>ID</th><th>Название</th><th>Превью</th><th></th></tr></thead>
              <tbody id="siteTemplatesBody"></tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    const tbody = document.getElementById("siteTemplatesBody");
    templates.forEach((t) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><code>${t.id}</code></td>
        <td></td>
        <td class="muted">${
          t.preview
            ? `<a href="${escapeHtml(t.preview)}" target="_blank" rel="noopener"><img src="${escapeHtml(
                t.preview
              )}" alt="" width="72" height="44" style="width:72px;height:44px;object-fit:cover;border-radius:6px;vertical-align:middle" /></a>`
            : "—"
        }</td>
        <td></td>
      `;
      const nameCell = tr.children[1];
      const nameInput = document.createElement("input");
      nameInput.className = "search-input";
      nameInput.style.maxWidth = "220px";
      nameInput.maxLength = 80;
      nameInput.value = t.name || `Template #${t.id}`;
      nameInput.addEventListener("keydown", async (e) => {
        if (e.key !== "Enter") return;
        const name = nameInput.value.trim();
        if (!name) {
          toast("Укажите название", "error");
          return;
        }
        try {
          await PanelAPI.patch(`/admin/sites/templates/visibility/${t.id}`, { name });
          toast(`Название #${t.id} обновлено`);
          await mountTemplatesVisibility(container, { onMeta });
        } catch (err) {
          toast(err.message, "error");
        }
      });
      nameCell.appendChild(nameInput);

      const actions = tr.lastElementChild;
      const saveBtn = document.createElement("button");
      saveBtn.type = "button";
      saveBtn.className = "btn-ghost";
      saveBtn.textContent = "Сохранить";
      saveBtn.addEventListener("click", async () => {
        const name = nameInput.value.trim();
        if (!name) {
          toast("Укажите название", "error");
          return;
        }
        try {
          await PanelAPI.patch(`/admin/sites/templates/visibility/${t.id}`, { name });
          toast(`Название #${t.id} обновлено`);
          await mountTemplatesVisibility(container, { onMeta });
        } catch (err) {
          toast(err.message, "error");
        }
      });
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn-ghost btn-danger";
      btn.textContent = "Выключить";
      btn.addEventListener("click", async () => {
        try {
          await PanelAPI.del(`/admin/sites/templates/visibility/${t.id}`);
          toast(`Шаблон #${t.id} выключен`);
          await mountTemplatesVisibility(container, { onMeta });
        } catch (e) {
          toast(e.message, "error");
        }
      });
      actions.appendChild(saveBtn);
      actions.appendChild(btn);
      tbody.appendChild(tr);
    });
    if (!templates.length) {
      tbody.innerHTML = `<tr><td colspan="4" class="muted">Нет включённых шаблонов — пользователи их не видят</td></tr>`;
    }

    const enable = async () => {
      const id = document.getElementById("siteTemplateIdInput").value.trim();
      const name = document.getElementById("siteTemplateNameInput").value.trim();
      if (!id) {
        toast("Укажите ID шаблона", "error");
        return;
      }
      try {
        const result = await PanelAPI.post("/admin/sites/templates/visibility", { id, name });
        const savedName = result.template?.name || `#${id}`;
        toast(`Включён: ${savedName}`);
        document.getElementById("siteTemplateIdInput").value = "";
        document.getElementById("siteTemplateNameInput").value = "";
        await mountTemplatesVisibility(container, { onMeta });
      } catch (e) {
        toast(e.message, "error");
      }
    };
    document.getElementById("siteTemplateEnable").addEventListener("click", enable);
    document.getElementById("siteTemplateIdInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter") enable();
    });
    document.getElementById("siteTemplateNameInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter") enable();
    });

    const createHint = document.getElementById("adminTemplateHint");
    const setCreateHint = (text) => {
      if (!createHint) return;
      const value = String(text || "").trim();
      createHint.textContent = value;
      createHint.hidden = !value;
    };
    const fileInput = document.getElementById("adminTemplateFile");
    const fileNameEl = document.getElementById("adminTemplateFileName");
    document.getElementById("adminTemplateFileBtn")?.addEventListener("click", () => {
      fileInput?.click();
    });
    fileInput?.addEventListener("change", async (event) => {
      const file = event.target.files?.[0];
      const nameInput = document.getElementById("adminTemplateName");
      const codeInput = document.getElementById("adminTemplateCode");
      if (!file) {
        if (fileNameEl) {
          fileNameEl.textContent = "";
          fileNameEl.hidden = true;
        }
        return;
      }
      try {
        if (codeInput) codeInput.value = await file.text();
        if (nameInput && !nameInput.value.trim()) {
          nameInput.value = String(file.name || "").replace(/\.html?$/i, "").slice(0, 80);
        }
        if (fileNameEl) {
          fileNameEl.textContent = file.name;
          fileNameEl.hidden = false;
        }
        setCreateHint("");
      } catch (error) {
        setCreateHint(error.message || "Не удалось прочитать файл");
      }
    });
    document.getElementById("adminTemplateCreate")?.addEventListener("click", async () => {
      const nameInput = document.getElementById("adminTemplateName");
      const codeInput = document.getElementById("adminTemplateCode");
      const submitBtn = document.getElementById("adminTemplateCreate");
      const name = String(nameInput?.value || "").trim();
      const code = String(codeInput?.value || "").trim();
      if (!name) {
        setCreateHint("Укажите название шаблона");
        nameInput?.focus();
        return;
      }
      if (!code) {
        setCreateHint("Пришлите HTML-код шаблона");
        codeInput?.focus();
        return;
      }
      submitBtn.disabled = true;
      setCreateHint("");
      try {
        const result = await PanelAPI.post("/admin/sites/templates", {
          name,
          code,
          isPublic: Boolean(document.getElementById("adminTemplatePublic")?.checked),
        });
        const savedName = result.template?.name || name;
        toast(`Создан шаблон: ${savedName}`);
        await mountTemplatesVisibility(container, { onMeta });
      } catch (error) {
        setCreateHint(error.message || "Не удалось создать шаблон");
        toast(error.message, "error");
        submitBtn.disabled = false;
      }
    });
  }

  async function renderSteam() {
    main.innerHTML = `
      <div class="greeting">
        <div>
          <h1 class="greeting-title">Логи Steam</h1>
          <p class="greeting-sub">Последние аккаунты панели · поиск по ID</p>
        </div>
      </div>
      <div class="panel-card">
        <div class="panel-card-body" style="padding-top:16px">
          <div class="search-row">
            <input class="search-input" id="steamId" placeholder="ID лога (цифры) или оставьте пустым" />
            <button type="button" class="btn-primary" id="steamSearch">Найти</button>
            <button type="button" class="btn-ghost" id="steamRefresh">Обновить</button>
          </div>
          <div class="table-wrap">
            <table class="data">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Логин</th>
                    <th>Тип</th>
                    <th>Цена</th>
                    <th>Владелец</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody id="steamBody">
                  <tr><td colspan="6" class="muted">Загрузка…</td></tr>
                </tbody>
            </table>
          </div>
          <pre id="steamOut" hidden style="margin:14px 0 0;padding:12px;background:#202124;border-radius:10px;overflow:auto;font-size:12px;color:#b6b6b8;max-height:360px;white-space:pre-wrap"></pre>
        </div>
      </div>
    `;

    const body = document.getElementById("steamBody");
    const out = document.getElementById("steamOut");

    function rowCells(row) {
      const owner = row.owner?.telegram || row.owner?.username || "—";
      const kind = row.kindLabel || row.status || "—";
      const price =
        row.priceUsd != null && Number.isFinite(Number(row.priceUsd))
          ? `$${Number(row.priceUsd).toFixed(2)}`
          : "—";
      const kindClass = /mafile/i.test(String(row.kind || kind))
        ? "ok"
        : /invalid|невалид/i.test(String(row.status || ""))
          ? "bad"
          : "ok";
      return `
        <td class="muted">${escapeHtml(row.id ?? "—")}</td>
        <td>${escapeHtml(row.username || "—")}</td>
        <td><span class="badge ${kindClass}">${escapeHtml(kind)}</span></td>
        <td>${escapeHtml(price)}</td>
        <td class="muted">${escapeHtml(owner)}</td>
        <td></td>
      `;
    }

    async function loadList() {
      body.innerHTML = `<tr><td colspan="6" class="muted">Загрузка…</td></tr>`;
      out.hidden = true;
      try {
        const data = await PanelAPI.get("/admin/steam-logs");
        const rows = Array.isArray(data) ? data : data?.rows || data?.data || [];
        body.innerHTML = "";
        if (!rows.length) {
          body.innerHTML = `<tr><td colspan="6" class="muted">Логи не найдены</td></tr>`;
          return;
        }
        rows.forEach((row) => {
          const tr = document.createElement("tr");
          tr.className = "clickable-row";
          tr.innerHTML = rowCells(row);
          const btnCell = tr.lastElementChild;
          const openBtn = document.createElement("button");
          openBtn.type = "button";
          openBtn.className = "btn-ghost";
          openBtn.textContent = "JSON";
          openBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            out.hidden = false;
            out.textContent = JSON.stringify(row, null, 2);
          });
          btnCell.appendChild(openBtn);
          tr.addEventListener("click", () => {
            document.getElementById("steamId").value = String(row.id || "");
            loadById(String(row.id || ""));
          });
          body.appendChild(tr);
        });
      } catch (e) {
        body.innerHTML = `<tr><td colspan="5" class="muted">Ошибка: ${escapeHtml(e.message)}</td></tr>`;
        toast(e.message, "error");
      }
    }

    async function loadById(id) {
      if (!id) return loadList();
      body.innerHTML = `<tr><td colspan="5" class="muted">Загрузка #${escapeHtml(id)}…</td></tr>`;
      out.hidden = true;
      try {
        const data = await PanelAPI.get(`/admin/steam-logs?id=${encodeURIComponent(id)}`);
        const account = data?.account || data;
        body.innerHTML = "";
        const tr = document.createElement("tr");
        tr.innerHTML = rowCells(account);
        body.appendChild(tr);
        out.hidden = false;
        out.textContent = JSON.stringify(account, null, 2);
      } catch (e) {
        body.innerHTML = `<tr><td colspan="5" class="muted">Ошибка: ${escapeHtml(e.message)}</td></tr>`;
        toast(e.message, "error");
      }
    }

    document.getElementById("steamSearch").addEventListener("click", () => {
      loadById(document.getElementById("steamId").value.trim());
    });
    document.getElementById("steamRefresh").addEventListener("click", loadList);
    document.getElementById("steamId").addEventListener("keydown", (e) => {
      if (e.key === "Enter") loadById(e.target.value.trim());
    });
    await loadList();
  }

  async function renderBotLogs() {
    main.innerHTML = `
      <div class="greeting">
        <div>
          <h1 class="greeting-title">Логи бота</h1>
          <p class="greeting-sub">Последние 250 строк</p>
        </div>
        <button type="button" class="btn-primary" id="botLogsRefresh">Обновить</button>
      </div>
      <div class="panel-card">
        <div class="panel-card-body" style="padding-top:16px">
          <pre id="botLogsOut" style="margin:0;padding:12px;background:#202124;border-radius:10px;overflow:auto;font-size:12px;color:#b6b6b8;max-height:60vh;white-space:pre-wrap"></pre>
        </div>
      </div>
    `;
    async function load() {
      const text = await PanelAPI.get("/admin/bot-logs?lines=250");
      document.getElementById("botLogsOut").textContent = text;
    }
    document.getElementById("botLogsRefresh").addEventListener("click", load);
    await load();
  }

  function escapeHtml(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  const hash = location.hash.replace(/^#/, "");
  await showView(hash || "overview");
})();
