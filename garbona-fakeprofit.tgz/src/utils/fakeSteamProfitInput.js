function normalizeSteamIconHash(input) {
  const value = String(input || "").trim();
  return value.match(/economy\/image\/([^/?#]+)/i)?.[1] || value;
}

function tryParseLegacySkinLine(line) {
  const parts = String(line || "").trim().split(";");
  if (parts.length < 3 || !/^\d+([.,]\d+)?$/.test(parts[1].trim())) return null;
  const icon = normalizeSteamIconHash(parts[0]);
  const price = Number(parts[1].replace(",", "."));
  if (!icon || !Number.isFinite(price) || price < 0) return null;
  return { icon, price, itemHashName: parts.slice(2).join(";").trim() || "Unknown item" };
}

function parseMoneyLoose(raw) {
  const cleaned = String(raw || "")
    .trim()
    .replace(/^\$/, "")
    .replace(/\s/g, "")
    .replace(",", ".");
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : null;
}

const POPULAR_GAMES = Object.freeze([
  { appid: 730, name: "Counter-Strike 2", playtime_forever: 9000 },
  { appid: 252490, name: "Rust", playtime_forever: 4200 },
  { appid: 359550, name: "Rainbow Six Siege", playtime_forever: 1800 },
  { appid: 570, name: "Dota 2", playtime_forever: 600 },
]);

function buildFakeProfitGames(count = 4) {
  const safe = Math.max(0, Math.min(4, Math.trunc(Number(count) || 0)));
  return POPULAR_GAMES.slice(0, safe);
}

function parseFakeSteamProfitMeta(text) {
  const lines = String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !/^[-—]{3,}$/.test(line));

  const meta = {
    balanceUsd: 0,
    mafileTime: "",
    gamesCount: 4,
  };
  const skinLines = [];

  for (const line of lines) {
    const labeled = line.match(/^(баланс|balance|mafile|игры|games)\s*[:=]\s*(.+)$/i);
    if (labeled) {
      const key = labeled[1].toLowerCase();
      const value = labeled[2].trim();
      if (/^(баланс|balance)$/.test(key)) {
        const parsed = parseMoneyLoose(value);
        if (parsed == null) return { error: "Некорректный баланс Steam." };
        meta.balanceUsd = Math.max(0, parsed);
      } else if (/^mafile$/.test(key)) {
        meta.mafileTime = value;
      } else if (/^(игры|games)$/.test(key)) {
        const count = Number(String(value).replace(/[^\d.-]/g, ""));
        if (!Number.isFinite(count) || count < 0 || count > 4) {
          return { error: "Игры: укажите число от 0 до 4." };
        }
        meta.gamesCount = Math.trunc(count);
      }
      continue;
    }
    skinLines.push(line);
  }

  if (skinLines.length < 5 || skinLines.length > 7) {
    return {
      error: `Нужно 5–7 строк со скинами (без мета-полей). Сейчас: ${skinLines.length}.`,
    };
  }

  return { ...meta, skinLines };
}

const FAKE_STEAM_PROFIT_SKINS_INSTRUCTION_HTML = [
  "<b>Фейк-профит</b>",
  "",
  "Опционально — мета-поля (с подписями):",
  "<code>баланс: 12.50",
  "mafile: 39",
  "игры: 4</code>",
  "",
  "Затем <b>5–7 строк</b> — по одному скину CS2 как на Steam Market.",
  "Или ручной формат: <code>хеш_иконки;цена;название</code>",
].join("\n");

module.exports = {
  normalizeSteamIconHash,
  tryParseLegacySkinLine,
  parseFakeSteamProfitMeta,
  buildFakeProfitGames,
  FAKE_STEAM_PROFIT_SKINS_INSTRUCTION_HTML,
};
