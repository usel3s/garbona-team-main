"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");
const {
  parseFakeSteamProfitMeta,
  buildFakeProfitGames,
  tryParseLegacySkinLine,
} = require("../src/utils/fakeSteamProfitInput");
const { renderSteamProfitImage } = require("../src/utils/steamImageRenderer");

test("parseFakeSteamProfitMeta splits meta and skin lines", () => {
  const parsed = parseFakeSteamProfitMeta([
    "баланс: 300",
    "mafile: 39",
    "игры: 3",
    "AK-47 | Redline (Field-Tested)",
    "AWP | Asiimov (Field-Tested)",
    "M4A1-S | Hot Rod (Factory New)",
    "USP-S | Kill Confirmed (Minimal Wear)",
    "Glock-18 | Fade (Factory New)",
  ].join("\n"));

  assert.equal(parsed.balanceUsd, 300);
  assert.equal(parsed.mafileTime, "39");
  assert.equal(parsed.gamesCount, 3);
  assert.equal(parsed.skinLines.length, 5);
});

test("parseFakeSteamProfitMeta rejects wrong skin count", () => {
  const parsed = parseFakeSteamProfitMeta("AK-47 | Redline (Field-Tested)");
  assert.match(parsed.error, /5–7/);
});

test("buildFakeProfitGames returns capped popular games", () => {
  assert.equal(buildFakeProfitGames(2).length, 2);
  assert.equal(buildFakeProfitGames(2)[0].appid, 730);
  assert.equal(buildFakeProfitGames(9).length, 4);
});

test("legacy skin line parser still works", () => {
  const item = tryParseLegacySkinLine("abc123;12.5;AK-47 | Redline (Field-Tested)");
  assert.equal(item.price, 12.5);
  assert.match(item.itemHashName, /Redline/);
});

test("renderSteamProfitImage renders PNG with worker share and balance", async () => {
  const buffer = await renderSteamProfitImage({
    items: [
      { itemHashName: "AWP | Asiimov (Field-Tested)", price: 120.5 },
      { itemHashName: "AK-47 | Redline (Field-Tested)", price: 45.2 },
    ],
    games: buildFakeProfitGames(2),
    total: 365.7,
    balanceUsd: 200,
    inventoryUsd: 165.7,
    mafileTime: "39",
    workerShare: 292.56,
    workerPercent: 80,
  });

  assert.equal(buffer.subarray(0, 8).toString("hex"), "89504e470d0a1a0a");
  assert.ok(buffer.length > 5000);
});
